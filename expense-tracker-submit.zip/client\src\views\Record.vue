<template>
  <div class="record-page">
    <div class="page-head">
      <div>
        <div class="page-eyebrow font-label">// DATA INPUT TERMINAL</div>
        <h1 class="page-title font-display">记账</h1>
      </div>
      <div class="head-right">
        <el-radio-group v-model="mode" @change="onModeChange">
          <el-radio-button label="expense">支出</el-radio-button>
          <el-radio-button label="income">收入</el-radio-button>
        </el-radio-group>
        <el-button v-if="mode==='expense'" type="primary" @click="doExport">导出 XLSX</el-button>
      </div>
    </div>

    <div class="record-grid">
      <!-- 录入表单 -->
      <div class="cyber-panel form-panel">
        <div class="panel-head"><span class="label-tag">{{ editing ? 'EDIT' : 'NEW' }}</span><span class="panel-title font-display">{{ editing ? '修改记录' : (mode==='expense' ? '录入支出' : '录入收入') }}</span></div>
        <el-form :model="form" label-position="top" class="cyber-form">
          <el-form-item label="金额 / CNY">
            <el-input v-model.number="form.amount" type="number" placeholder="0.00">
              <template #prefix><span :class="mode==='expense' ? 'neon' : 'neon-cyan'">¥</span></template>
            </el-input>
          </el-form-item>
          <el-form-item v-if="mode==='expense'" label="类别">
            <el-select v-model="form.category" placeholder="选择类别" style="width:100%">
              <el-option v-for="c in CATEGORIES" :key="c" :label="c" :value="c" />
            </el-select>
          </el-form-item>
          <el-form-item v-if="mode==='expense'" label="消费动机">
            <el-select v-model="form.motive" placeholder="选择动机" style="width:100%">
              <el-option v-for="m in MOTIVES" :key="m" :label="m" :value="m" />
            </el-select>
          </el-form-item>
          <el-form-item v-else label="来源">
            <el-select v-model="form.source" placeholder="选择来源" style="width:100%">
              <el-option v-for="s in INCOME_SOURCES" :key="s" :label="s" :value="s" />
            </el-select>
          </el-form-item>
          <el-form-item label="日期">
            <el-date-picker v-model="form.date" type="date" format="YYYY-MM-DD" value-format="YYYY-MM-DD" style="width:100%" />
          </el-form-item>
          <el-form-item label="备注">
            <el-input v-model="form.note" placeholder="可选..." />
          </el-form-item>
          <div class="form-actions">
            <el-button type="primary" @click="submit">{{ editing ? '更新' : '提交' }}</el-button>
            <el-button v-if="editing" @click="resetForm">取消</el-button>
          </div>
        </el-form>
      </div>

      <!-- 列表 -->
      <div class="cyber-panel list-panel">
        <div class="panel-head">
          <span class="label-tag">LOG</span><span class="panel-title font-display">{{ mode==='expense' ? '支出明细' : '收入明细' }}</span>
          <div class="filters">
            <el-date-picker v-model="range" type="daterange" range-separator="→" start-placeholder="起" end-placeholder="止" format="YYYY-MM-DD" value-format="YYYY-MM-DD" size="small" @change="loadList" />
            <el-select v-model="filterCat" :placeholder="mode==='expense'?'类别':'来源'" size="small" style="width:110px" @change="loadList">
              <el-option label="全部" value="全部" />
              <el-option v-for="c in (mode==='expense'?CATEGORIES:INCOME_SOURCES)" :key="c" :label="c" :value="c" />
            </el-select>
          </div>
        </div>

        <el-table :data="pageData" stripe style="width:100%" empty-text="// NO DATA">
          <el-table-column label="日期" prop="date" width="120" />
          <el-table-column :label="mode==='expense'?'类别':'来源'" width="100">
            <template #default="{ row }"><span class="cell-cat" :style="{ color: mode==='expense' ? catColor(row.category) : '#00d4ff' }">{{ mode==='expense' ? row.category : row.source }}</span></template>
          </el-table-column>
          <el-table-column label="金额" width="120">
            <template #default="{ row }"><span class="cell-amt" :style="{ color: mode==='expense' ? 'var(--accent)' : 'var(--accent-3)' }">{{ mode==='expense' ? '-' : '+' }}¥{{ fmt(row.amount) }}</span></template>
          </el-table-column>
          <el-table-column label="备注" prop="note" show-overflow-tooltip />
          <el-table-column label="操作" width="130" fixed="right">
            <template #default="{ row }">
              <el-button size="small" @click="edit(row)">编辑</el-button>
              <el-button size="small" type="danger" @click="remove(row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <div class="pager">
          <el-pagination v-model:current-page="page" :page-size="pageSize" :total="list.length" layout="prev, pager, next, total" background />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { expenseApi, incomeApi, exportExcel, CATEGORIES, MOTIVES } from '../api/index.js';
import { NEON_COLORS } from '../utils/chart.js';

const INCOME_SOURCES = ['生活费', '兼职', '奖学金', '红包', '理财', '其他'];
const fmt = (n) => (Number(n) || 0).toFixed(2);
const catColor = (c) => NEON_COLORS[CATEGORIES.indexOf(c) % NEON_COLORS.length] || '#00ff88';

const mode = ref('expense');
const today = () => new Date().toISOString().slice(0, 10);
const form = reactive({ amount: null, category: '餐饮', motive: '刚需', source: '生活费', date: today(), note: '' });
const editing = ref(null);

const list = ref([]);
const range = ref([]);
const filterCat = ref('全部');
const page = ref(1);
const pageSize = 8;
const pageData = computed(() => list.value.slice((page.value - 1) * pageSize, page.value * pageSize));

function resetForm() {
  form.amount = null; form.category = '餐饮'; form.motive = '刚需'; form.source = '生活费'; form.date = today(); form.note = '';
  editing.value = null;
}

function onModeChange() { filterCat.value = '全部'; resetForm(); loadList(); }

async function loadList() {
  const params = {};
  if (range.value && range.value.length === 2) { params.start = range.value[0]; params.end = range.value[1]; }
  if (filterCat.value && filterCat.value !== '全部') {
    if (mode.value === 'expense') params.category = filterCat.value;
    else params.source = filterCat.value;
  }
  list.value = mode.value === 'expense' ? await expenseApi.list(params) : await incomeApi.list(params);
}

async function submit() {
  if (!form.amount || !form.date) return ElMessage.warning('请填写完整');
  if (Number(form.amount) <= 0) return ElMessage.warning('金额需大于 0');
  const api = mode.value === 'expense' ? expenseApi : incomeApi;
  const fieldValue = mode.value === 'expense' ? form.category : form.source;
  if (!fieldValue) return ElMessage.warning('请选择类别/来源');
  const fieldKey = mode.value === 'expense' ? 'category' : 'source';
  const payload = { [fieldKey]: fieldValue, amount: Number(form.amount), date: form.date, note: form.note, ...(mode.value === 'expense' ? { motive: form.motive } : {}) };
  if (editing.value) {
    await api.update(editing.value, payload);
    ElMessage.success('记录已更新');
  } else {
    await api.create(payload);
    ElMessage.success('记录已写入');
  }
  resetForm();
  await loadList();
}

function edit(row) {
  editing.value = row.id;
  form.amount = row.amount; form.date = row.date; form.note = row.note || '';
  if (mode.value === 'expense') { form.category = row.category; form.motive = row.motive || '刚需'; } else form.source = row.source;
}

async function remove(row) {
  const label = mode.value === 'expense' ? row.category : row.source;
  await ElMessageBox.confirm(`删除 ${row.date} ${label} ¥${fmt(row.amount)} ?`, '确认', { type: 'warning' });
  const api = mode.value === 'expense' ? expenseApi : incomeApi;
  await api.remove(row.id);
  ElMessage.success('已删除');
  await loadList();
}

async function doExport() {
  const params = {};
  if (range.value && range.value.length === 2) { params.start = range.value[0]; params.end = range.value[1]; }
  if (filterCat.value && filterCat.value !== '全部') params.category = filterCat.value;
  await exportExcel(params);
  ElMessage.success('导出完成');
}

onMounted(loadList);
</script>

<style scoped>
.record-page { display: flex; flex-direction: column; gap: 20px; }
.page-head { display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 12px; }
.page-eyebrow { color: var(--accent-3); font-size: 12px; }
.page-title { font-size: 26px; font-weight: 900; color: var(--fg); margin: 4px 0 0; }
.head-right { display: flex; gap: 10px; align-items: center; }

.record-grid { display: grid; grid-template-columns: 340px 1fr; gap: 16px; align-items: start; }
.form-panel { padding: 18px; position: sticky; top: 0; }
.panel-head { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; flex-wrap: wrap; }
.panel-title { color: var(--fg); font-size: 15px; }
.filters { margin-left: auto; display: flex; gap: 8px; }

.cyber-form :deep(.el-form-item__label) { font-size: 11px; }
.form-actions { display: flex; gap: 10px; margin-top: 6px; }

.list-panel { padding: 18px; }
.cell-cat { font-family: "Share Tech Mono", monospace; font-size: 12px; }
.cell-amt { font-weight: 700; }
.pager { display: flex; justify-content: flex-end; margin-top: 14px; }

@media (max-width: 980px) { .record-grid { grid-template-columns: 1fr; } .form-panel { position: static; } }
</style>