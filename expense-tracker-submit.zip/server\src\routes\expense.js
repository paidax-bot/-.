import { Router } from 'express';
import { Op } from 'sequelize';
import { Expense } from '../db.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const { start, end, category } = req.query;
    const where = {};
    if (start && end) where.date = { [Op.between]: [start, end] };
    else if (start) where.date = { [Op.gte]: start };
    else if (end) where.date = { [Op.lte]: end };
    if (category && category !== '全部') where.category = category;
    const rows = await Expense.findAll({ where, order: [['date', 'DESC'], ['created_at', 'DESC']] });
    res.json(rows);
  } catch (e) { next(e); }
});

router.post('/', async (req, res, next) => {
  try {
    const row = await Expense.create(req.body);
    res.json(row);
  } catch (e) { next(e); }
});

router.put('/:id', async (req, res, next) => {
  try {
    const row = await Expense.findByPk(req.params.id);
    if (!row) return res.status(404).json({ error: 'not found' });
    await row.update(req.body);
    res.json(row);
  } catch (e) { next(e); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const row = await Expense.findByPk(req.params.id);
    if (!row) return res.status(404).json({ error: 'not found' });
    await row.destroy();
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default router;