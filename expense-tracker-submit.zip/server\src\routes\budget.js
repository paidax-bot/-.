import { Router } from 'express';
import { Op } from 'sequelize';
import { Budget } from '../db.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const { month } = req.query;
    const where = {};
    if (month) where.month = month;
    const rows = await Budget.findAll({ where, order: [['category', 'ASC']] });
    res.json(rows);
  } catch (e) { next(e); }
});

router.post('/', async (req, res, next) => {
  try {
    const { category, month, limitAmount } = req.body;
    const [row, created] = await Budget.findOrCreate({
      where: { category, month },
      defaults: { limitAmount }
    });
    if (!created) {
      await row.update({ limitAmount });
    }
    res.json(row);
  } catch (e) { next(e); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const row = await Budget.findByPk(req.params.id);
    if (!row) return res.status(404).json({ error: 'not found' });
    await row.destroy();
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default router;