<template>
  <div class="mind-page">
    <div class="page-head">
      <div>
        <div class="page-eyebrow font-label">// PSYCHOLOGICAL ASSESSMENT</div>
        <h1 class="page-title font-display">消费心理</h1>
      </div>
      <el-date-picker v-model="month" type="month" format="YYYY-MM" value-format="YYYY-MM" :clearable="false" @change="run" />
    </div>

    <div v-if="!result.hasData" class="empty-state cyber-panel">
      <div class="empty-icon">⊘</div>
      <div class="empty-text font-label">// {{ month }} 无消费记录，无法测评</div>
      <div class="empty-hint">前往「记账」录入支出（记得选消费动机）后再来</div>
    </div>

    <template v-else>
      <div class="cyber-panel emotion-panel">
        <div class="panel-head"><span class="label-tag">EMOTION</span><span class="panel-title font-display">情绪化消费占比</span></div>
        <div class="emotion-wrap">
          <div class="emotion-pct font-display neon-pink">{{ result.emotionRatio }}%</div>
          <div class="emotion-desc font-mono">解压 + 冲动 + 奖励自己 占本月消费比例</div>
          <div class="emotion-bar"><div class="emotion-fill" :style="{ width: Math.min(100, result.emotionRatio) + '%' }"></div></div>
          <div class="emotion-hint font-label" :class="result.emotionRatio > 30 ? 'warn' : 'ok'">{{ result.emotionRatio > 30 ? '⚠ 情绪化消费偏高，注意情绪调节' : '● 情绪化消费在合理范围' }}</div>
        </div>
      </div>

      <div class="top-grid">
        <div class="cyber-panel badge-panel">
          <div class="panel-head"><span class="label-tag">PSY</span><span class="panel-title font-display">心理素质评级</span></div>
          <div class="badge-wrap">
            <div class="badge" :style="{ '--bc': result.color }">
              <div class="badge-ring"></div>
              <div class="badge-grade font-display" :style="{ color: result.color, textShadow: '0 0 18px ' + result.color }">{{ result.grade }}</div>
            </div>
            <div class="badge-info">
              <div class="bi-score font-display" :style="{ color: result.color }">{{ result.totalScore }}</div>
              <div class="bi-level font-label" :style="{ color: result.color }">{{ result.level }}</div>
              <div class="bi-month font-mono">{{ result.month }} · 支出 ¥{{ fmt(result.total) }}</div>
            </div>
          </div>
        </div>

        <div class="cyber-panel radar-panel">
          <div class="panel-head"><span class="label-tag">RADAR</span><span class="panel-title font-display">五维心理画像</span></div>
          <div ref="radarEl" class="radar-canvas"></div>
        </div>
      </div>

      <div class="cyber-panel dim-panel">
        <div class="panel-head"><span class="label-tag">DETAIL</span><span class="panel-title font-display">维度明细</span></div>
        <div class="dim-grid">
          <div v-for="d in result.dimensions" :key="d.key" class="dim-card">
            <div class="dim-top">
              <span class="dim-name font-label">{{ d.name }}</span>
              <span class="dim-score font-display" :style="{ color: scoreColor(d.score) }">{{ d.score }}</span>
            </div>
            <div class="dim-bar"><div class="dim-fill" :style="{ width: d.score + '%', background: scoreColor(d.score) }"></div></div>
            <div class="dim-comment font-mono">{{ d.comment }}</div>
          </div>
        </div>
      </div>

      <div class="cyber-panel sugg-panel">
        <div class="panel-head"><span class="label-tag">ADVICE</span><span class="panel-title font-display">心理调节建议</span></div>
        <div class="sugg-list">
          <div v-for="(s, i) in result.suggestions" :key="i" class="sugg-row">
            <span class="sugg-idx font-label">0{{ i + 1 }}</span>
            <span class="sugg-text font-mono">{{ s }}</span>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, nextTick } from 'vue';
import { mindApi } from '../api/index.js';
import { makeChart, tooltipStyle } from '../utils/chart.js';

const fmt = (n) => (Number(n) || 0).toFixed(2);
const scoreColor = (s) => s >= 80 ? '#00ff88' : s >= 60 ? '#ffaa00' : '#ff3366';

const month = ref(new Date().toISOString().slice(0, 7));
const result = ref({ hasData: false, dimensions: [], suggestions: [], grade: '-', totalScore: 0, color: '#ff00ff', emotionRatio: 0 });
const radarEl = ref(null);
let radarChart = null;

async function run() {
  result.value = await mindApi.run({ month: month.value });
  if (result.value.hasData) { await nextTick(); renderRadar(); }
}

function renderRadar() {
  if (!radarEl.value) return;
  if (!radarChart) radarChart = makeChart(radarEl.value);
  const dims = result.value.dimensions;
  radarChart.chart.setOption({
    tooltip: { ...tooltipStyle },
    radar: {
      indicator: dims.map(d => ({ name: d.name, max: 100 })),
      shape: 'polygon', center: ['50%', '54%'], radius: '68%',
      axisName: { color: '#c0c0d0', fontFamily: 'Share Tech Mono', fontSize: 12 },
      splitLine: { lineStyle: { color: '#2a2a3a' } },
      splitArea: { areaStyle: { color: ['transparent', 'rgba(255,0,255,.04)'] } },
      axisLine: { lineStyle: { color: '#2a2a3a' } }
    },
    series: [{
      type: 'radar',
      data: [{
        value: dims.map(d => d.score), name: '心理画像',
        areaStyle: { color: 'rgba(255,0,255,.22)' },
        lineStyle: { color: '#ff00ff', width: 2, shadowBlur: 10, shadowColor: 'rgba(255,0,255,.6)' },
        itemStyle: { color: '#ff00ff', borderColor: '#0a0a0f', borderWidth: 2 }
      }]
    }]
  }, true);
}

onMounted(run);
onUnmounted(() => { radarChart?.dispose(); });
</script>

<style scoped>
.mind-page { display: flex; flex-direction: column; gap: 20px; }
.page-head { display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 12px; }
.page-eyebrow { color: var(--accent-3); font-size: 12px; }
.page-title { font-size: 26px; font-weight: 900; color: var(--fg); margin: 4px 0 0; }

.empty-state { padding: 60px 20px; text-align: center; }
.empty-icon { font-size: 48px; color: var(--muted-fg); }
.empty-text { color: var(--accent-3); font-size: 14px; margin-top: 12px; }
.empty-hint { color: var(--muted-fg); font-size: 12px; margin-top: 6px; }

.emotion-panel { padding: 18px; }
.panel-head { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
.panel-title { color: var(--fg); font-size: 15px; }
.emotion-wrap { text-align: center; padding: 10px 0; }
.emotion-pct { font-size: 42px; font-weight: 900; }
.emotion-desc { color: var(--muted-fg); font-size: 12px; margin: 6px 0 14px; }
.emotion-bar { height: 10px; background: var(--muted); overflow: hidden; max-width: 400px; margin: 0 auto; }
.emotion-fill { height: 100%; background: linear-gradient(90deg, #ff00ff, #ff3366); box-shadow: 0 0 10px rgba(255,0,255,.5); transition: width .6s; }
.emotion-hint { font-size: 12px; margin-top: 12px; }
.emotion-hint.ok { color: var(--accent); }
.emotion-hint.warn { color: var(--destructive); }

.top-grid { display: grid; grid-template-columns: 1fr 1.3fr; gap: 16px; }
.badge-panel { padding: 18px; }
.badge-wrap { display: flex; align-items: center; gap: 28px; justify-content: center; padding: 16px 0; }
.badge { width: 120px; height: 120px; position: relative; display: flex; align-items: center; justify-content: center; }
.badge-ring { position: absolute; inset: 0; border: 3px solid var(--bc, var(--accent-2)); border-radius: 50%; box-shadow: 0 0 24px var(--bc, var(--accent-2)); animation: pulse-glow 2.4s infinite; }
.badge-grade { font-size: 64px; font-weight: 900; z-index: 1; animation: flicker 5s infinite; }
.badge-info { text-align: left; }
.bi-score { font-size: 48px; font-weight: 900; line-height: 1; }
.bi-level { font-size: 16px; margin-top: 4px; }
.bi-month { color: var(--muted-fg); font-size: 12px; margin-top: 10px; }

.radar-panel { padding: 18px; }
.radar-canvas { width: 100%; height: 320px; }

.dim-panel { padding: 18px; }
.dim-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 14px; }
.dim-card { background: var(--bg-2); border: 1px solid var(--border); border-top: 2px solid var(--accent-2); padding: 14px; }
.dim-top { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 8px; }
.dim-name { color: var(--accent-3); font-size: 12px; }
.dim-score { font-size: 24px; font-weight: 700; }
.dim-bar { height: 5px; background: var(--muted); overflow: hidden; margin-bottom: 8px; }
.dim-fill { height: 100%; transition: width .6s; box-shadow: 0 0 6px currentColor; }
.dim-comment { color: var(--muted-fg); font-size: 11px; line-height: 1.5; }

.sugg-panel { padding: 18px; }
.sugg-list { display: flex; flex-direction: column; gap: 10px; }
.sugg-row { display: flex; gap: 14px; align-items: flex-start; padding: 10px 14px; background: var(--bg-2); border-left: 2px solid var(--accent-2); }
.sugg-idx { color: var(--accent-2); font-size: 13px; }
.sugg-text { color: var(--fg); font-size: 13px; line-height: 1.5; }

@media (max-width: 980px) { .top-grid { grid-template-columns: 1fr; } .dim-grid { grid-template-columns: repeat(2,1fr); } }
</style>