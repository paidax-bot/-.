import { Router } from 'express';
import { Wishlist } from '../db.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const rows = await Wishlist.findAll({ order: [['created_at', 'DESC']] });
    const now = new Date();
    const list = rows.map(r => {
      const added = new Date(r.addedDate);
      const coolEnd = new Date(added.getTime() + r.coolDays * 86400000);
      const daysLeft = Math.ceil((coolEnd - now) / 86400000);
      return {
        ...r.toJSON(),
        coolEnd: coolEnd.toISOString().slice(0, 10),
        daysLeft,
        cooling: r.status === 'cooling' && daysLeft > 0,
        ready: r.status === 'cooling' && daysLeft <= 0
      };
    });
    res.json(list);
  } catch (e) { next(e); }
});

router.post('/', async (req, res, next) => {
  try { res.json(await Wishlist.create(req.body)); } catch (e) { next(e); }
});

router.put('/:id', async (req, res, next) => {
  try {
    const r = await Wishlist.findByPk(req.params.id);
    if (!r) return res.status(404).json({ error: 'not found' });
    await r.update(req.body);
    res.json(r);
  } catch (e) { next(e); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const r = await Wishlist.findByPk(req.params.id);
    if (!r) return res.status(404).json({ error: 'not found' });
    await r.destroy();
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default router;