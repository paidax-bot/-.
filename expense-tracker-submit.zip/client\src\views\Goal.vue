<template>
  <div class="goal-page">
    <div class="page-head">
      <div>
        <div class="page-eyebrow font-label">// SAVINGS TARGET</div>
        <h1 class="page-title font-display">存钱目标</h1>
      </div>
    </div>

    <div class="goal-grid2">
      <div class="cyber-panel form-panel">
        <div class="panel-head"><span class="label-tag">SET</span><span class="panel-title font-display">设定目标</span></div>
        <el-form label-position="top">
          <el-form-item label="目标名称">
            <el-input v-model="form.name" placeholder="如 买新电脑" />
          </el-form-item>
          <el-form-item label="目标金额 / CNY">
            <el-input v-model.number="form.targetAmount" type="number" placeholder="如 5000">
              <template #prefix><span class="neon">¥</span></template>
            </el-input>
          </el-form-item>
          <el-form-item label="截止日期">
            <el-date-picker v-model="form.deadline" type="date" format="YYYY-MM-DD" value-format="YYYY-MM-DD" style="width:100%" />
          </el-form-item>
          <el-button type="primary" @click="save" style="width:100%">保存目标</el-button>
        </el-form>
        <div class="hint font-label">// 已存金额 = 累计收入 - 累计支出</div>
      </div>

      <div class="cyber-panel ring-panel">
        <div class="panel-head"><span class="label-tag">PROGRESS</span><span class="panel-title font-display">{{ goal?.name || '未设定' }}</span></div>
        <div v-if="goal" class="ring-wrap">
          <div ref="ringEl" class="ring-canvas"></div>
          <div class="ring-center">
            <div class="rc-saved font-display neon">¥{{ fmt(calc?.saved) }}</div>
            <div class="rc-target font-mono">/ ¥{{ fmt(goal.targetAmount) }}</div>
          </div>
        </div>
        <div v-else class="ring-empty">
          <div class="empty-icon">◎</div>
          <div class="empty-text font-label">// 尚未设定存钱目标</div>
          <div class="empty-hint">左侧填写目标后保存</div>
        </div>
      </div>
    </div>

    <div v-if="goal && calc" class="tiles">
      <div class="stat-tile tile">
        <div class="tile-label font-label">已存金额</div>
        <div class="tile-value neon">¥{{ fmt(calc.saved) }}</div>
        <div class="tile-foot font-mono">SAVED</div>
      </div>
      <div class="stat-tile tile">
        <div class="tile-label font-label">剩余金额</div>
        <div class="tile-value neon-pink">¥{{ fmt(calc.remaining) }}</div>
        <div class="tile-foot font-mono">REMAINING</div>
      </div>
      <div class="stat-tile tile">
        <div class="tile-label font-label">剩余天数</div>
        <div class="tile-value neon-cyan">{{ calc.daysLeft }}</div>
        <div class="tile-foot font-mono">DAYS LEFT</div>
      </div>
      <div class="stat-tile tile">
        <div class="tile-label font-label">每日应存</div>
        <div class="tile-value neon-pink">¥{{ fmt(calc.dailyNeed) }}</div>
        <div class="tile-foot font-mono">PER DAY</div>
      </div>
      <div class="stat-tile tile">
        <div class="tile-label font-label">预计达成</div>
        <div class="tile-value neon-cyan">{{ calc.forecastDate || '—' }}</div>
        <div class="tile-foot font-mono">月均存 ¥{{ fmt(calc.avgMonthlySavings) }}</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, onUnmounted, nextTick } from 'vue';
import { ElMessage } from 'element-plus';
import { goalApi } from '../api/index.js';
import { makeChart, tooltipStyle } from '../utils/chart.js';

const fmt = (n) => (Number(n) || 0).toFixed(2);
const today = () => new Date().toISOString().slice(0, 10);
const form = reactive({ name: '买新电脑', targetAmount: 5000, deadline: today() });
const goal = ref(null);
const calc = ref(null);
const ringEl = ref(null);
let ringChart = null;

async function load() {
  const data = await goalApi.get();
  goal.value = data.goal;
  calc.value = data.calc;
  if (data.goal) {
    form.name = data.goal.name;
    form.targetAmount = data.goal.targetAmount;
    form.deadline = data.goal.deadline;
  }
  await nextTick();
  renderRing();
}

async function save() {
  if (!form.targetAmount || Number(form.targetAmount) <= 0) return ElMessage.warning('请输入目标金额');
  if (!form.deadline) return ElMessage.warning('请选择截止日期');
  await goalApi.set({ name: form.name || '存钱目标', targetAmount: Number(form.targetAmount), deadline: form.deadline });
  ElMessage.success('目标已保存');
  await load();
}

function renderRing() {
  if (!ringEl.value || !calc.value) return;
  if (!ringChart) ringChart = makeChart(ringEl.value);
  ringChart.chart.setOption({
    tooltip: { ...tooltipStyle, formatter: '{b} {c}%' },
    series: [{
      type: 'gauge', radius: '90%', center: ['50%', '55%'],
      startAngle: 200, endAngle: -20,
      min: 0, max: 100,
      progress: { show: true, width: 16, roundCap: true, itemStyle: { color: '#00ff88', shadowBlur: 12, shadowColor: 'rgba(0,255,136,.6)' } },
      axisLine: { lineStyle: { width: 16, color: [[1, '#1c1c2e']] } },
      pointer: { show: false },
      axisTick: { show: false },
      splitLine: { show: false },
      axisLabel: { show: false },
      detail: { show: false },
      data: [{ value: calc.value.progress }]
    }]
  }, true);
}

onMounted(load);
onUnmounted(() => { ringChart?.dispose(); });
</script>

<style scoped>
.goal-page { display: flex; flex-direction: column; gap: 20px; }
.page-eyebrow { color: var(--accent-3); font-size: 12px; }
.page-title { font-size: 26px; font-weight: 900; color: var(--fg); margin: 4px 0 0; }

.goal-grid2 { display: grid; grid-template-columns: 340px 1fr; gap: 16px; align-items: start; }
.form-panel { padding: 18px; position: sticky; top: 0; }
.panel-head { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
.panel-title { color: var(--fg); font-size: 15px; }
.hint { color: var(--muted-fg); font-size: 11px; margin-top: 12px; text-align: center; }

.ring-panel { padding: 18px; }
.ring-wrap { position: relative; }
.ring-canvas { width: 100%; height: 280px; }
.ring-center { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -10%); text-align: center; }
.rc-saved { font-size: 32px; font-weight: 900; }
.rc-target { color: var(--muted-fg); font-size: 14px; margin-top: 4px; }
.ring-empty { padding: 60px 20px; text-align: center; }
.empty-icon { font-size: 56px; color: var(--muted-fg); }
.empty-text { color: var(--accent-3); font-size: 14px; margin-top: 12px; }
.empty-hint { color: var(--muted-fg); font-size: 12px; margin-top: 6px; }

.tiles { display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; }
.tile { padding: 20px; }
.tile-label { color: var(--muted-fg); font-size: 11px; }
.tile-value { font-family: "Orbitron", monospace; font-size: 24px; font-weight: 700; margin: 8px 0 4px; }
.tile-foot { color: var(--muted-fg); font-size: 11px; }

@media (max-width: 980px) { .goal-grid2 { grid-template-columns: 1fr; } .form-panel { position: static; } .tiles { grid-template-columns: repeat(2,1fr); } }
</style>