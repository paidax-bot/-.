import axios from 'axios';

const http = axios.create({ baseURL: '/api', timeout: 10000 });

export const CATEGORIES = ['餐饮', '交通', '学习', '娱乐', '日用品', '通讯', '其他'];
export const MOTIVES = ['刚需', '改善生活', '社交', '解压', '冲动', '奖励自己'];
export const EMOTION_MOTIVES = ['解压', '冲动', '奖励自己'];

export const expenseApi = {
  list: (params) => http.get('/expenses', { params }).then(r => r.data),
  create: (data) => http.post('/expenses', data).then(r => r.data),
  update: (id, data) => http.put(`/expenses/${id}`, data).then(r => r.data),
  remove: (id) => http.delete(`/expenses/${id}`).then(r => r.data)
};

export const statsApi = {
  summary: (params) => http.get('/stats/summary', { params }).then(r => r.data),
  category: (params) => http.get('/stats/category', { params }).then(r => r.data),
  trend: (params) => http.get('/stats/trend', { params }).then(r => r.data),
  calendar: (params) => http.get('/stats/calendar', { params }).then(r => r.data),
  balance: (params) => http.get('/stats/balance', { params }).then(r => r.data),
  motive: (params) => http.get('/stats/motive', { params }).then(r => r.data)
};

export const budgetApi = {
  list: (params) => http.get('/budgets', { params }).then(r => r.data),
  set: (data) => http.post('/budgets', data).then(r => r.data),
  remove: (id) => http.delete(`/budgets/${id}`).then(r => r.data)
};

export const profileApi = {
  get: () => http.get('/profile').then(r => r.data),
  update: (data) => http.put('/profile', data).then(r => r.data)
};

export const planApi = {
  generate: () => http.get('/plan').then(r => r.data)
};

export const assessmentApi = {
  run: (params) => http.get('/assessment', { params }).then(r => r.data)
};

export const seedApi = {
  run: () => http.post('/seed').then(r => r.data),
  clear: () => http.delete('/seed').then(r => r.data)
};

export const incomeApi = {
  list: (params) => http.get('/incomes', { params }).then(r => r.data),
  create: (data) => http.post('/incomes', data).then(r => r.data),
  update: (id, data) => http.put(`/incomes/${id}`, data).then(r => r.data),
  remove: (id) => http.delete(`/incomes/${id}`).then(r => r.data)
};

export const backupApi = {
  export: () => http.get('/backup').then(r => r.data),
  restore: (data) => http.post('/backup/restore', data).then(r => r.data)
};

export const goalApi = {
  get: () => http.get('/goal').then(r => r.data),
  set: (data) => http.put('/goal', data).then(r => r.data)
};

export const mindApi = {
  run: (params) => http.get('/mind', { params }).then(r => r.data)
};

export const wishlistApi = {
  list: () => http.get('/wishlist').then(r => r.data),
  create: (data) => http.post('/wishlist', data).then(r => r.data),
  update: (id, data) => http.put(`/wishlist/${id}`, data).then(r => r.data),
  remove: (id) => http.delete(`/wishlist/${id}`).then(r => r.data)
};

export function exportExcel(params) {
  return http.get('/export', { params, responseType: 'blob' }).then(r => {
    const url = URL.createObjectURL(r.data);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'expenses.xlsx';
    a.click();
    URL.revokeObjectURL(url);
  });
}

export default http;