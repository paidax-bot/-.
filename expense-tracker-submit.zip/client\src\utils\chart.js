import * as echarts from 'echarts';

export const NEON_COLORS = ['#00ff88', '#ff00ff', '#00d4ff', '#ffaa00', '#ff3366', '#a855f7', '#3afff0'];

export function makeChart(el) {
  const chart = echarts.init(el, null, { renderer: 'canvas' });
  const onResize = () => chart.resize();
  window.addEventListener('resize', onResize);
  return {
    chart,
    dispose: () => { window.removeEventListener('resize', onResize); chart.dispose(); }
  };
}

export const axisStyle = {
  axisLine: { lineStyle: { color: '#2a2a3a' } },
  axisTick: { lineStyle: { color: '#2a2a3a' } },
  axisLabel: { color: '#7a7a96', fontFamily: 'JetBrains Mono', fontSize: 11 },
  splitLine: { lineStyle: { color: '#16161f', type: 'dashed' } }
};

export const tooltipStyle = {
  backgroundColor: '#0d0d16',
  borderColor: '#00ff88',
  borderWidth: 1,
  textStyle: { color: '#e6e6f0', fontFamily: 'JetBrains Mono', fontSize: 12 },
  extraCssText: 'box-shadow: 0 0 14px rgba(0,255,136,.3);'
};

export function neonLineSeries(extra = {}) {
  return {
    type: 'line',
    smooth: true,
    symbol: 'circle',
    symbolSize: 7,
    lineStyle: { width: 2, color: '#00ff88', shadowColor: 'rgba(0,255,136,.6)', shadowBlur: 10 },
    itemStyle: { color: '#00ff88', borderColor: '#0a0a0f', borderWidth: 2 },
    areaStyle: {
      color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
        { offset: 0, color: 'rgba(0,255,136,.35)' },
        { offset: 1, color: 'rgba(0,255,136,0)' }
      ])
    },
    ...extra
  };
}