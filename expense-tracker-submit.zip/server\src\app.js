import express from 'express';
import cors from 'cors';
import { initDB } from './db.js';
import expenseRoutes from './routes/expense.js';
import statsRoutes from './routes/stats.js';
import budgetRoutes from './routes/budget.js';
import exportRoutes from './routes/export.js';
import profileRoutes from './routes/profile.js';
import planRoutes from './routes/plan.js';
import assessmentRoutes from './routes/assessment.js';
import seedRoutes from './routes/seed.js';
import incomeRoutes from './routes/income.js';
import backupRoutes from './routes/backup.js';
import goalRoutes from './routes/goal.js';
import mindRoutes from './routes/mind.js';
import wishlistRoutes from './routes/wishlist.js';

const app = express();

app.use(cors());
app.use(express.json());

app.get('/api/health', (_req, res) => res.json({ status: 'online', ts: Date.now() }));
app.use('/api/expenses', expenseRoutes);
app.use('/api/stats', statsRoutes);
app.use('/api/budgets', budgetRoutes);
app.use('/api/export', exportRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/plan', planRoutes);
app.use('/api/assessment', assessmentRoutes);
app.use('/api/seed', seedRoutes);
app.use('/api/incomes', incomeRoutes);
app.use('/api/backup', backupRoutes);
app.use('/api/goal', goalRoutes);
app.use('/api/mind', mindRoutes);
app.use('/api/wishlist', wishlistRoutes);

app.use((err, _req, res, _next) => {
  console.error('[ERR]', err);
  res.status(500).json({ error: err.message || 'server error' });
});

const PORT = 3000;
initDB().then(() => {
  app.listen(PORT, () => console.log(`[SERVER] http://localhost:${PORT}`));
});