import { Router } from 'express';
import { Op, fn, col, literal } from 'sequelize';
import { Expense, Income } from '../db.js';

const router = Router();

function monthRange(month) {
  return { start: `${month}-01`, end: `${month}-31` };
}

router.get('/summary', async (req, res, next) => {
  try {
    const { period = 'month', date } = req.query;
    let where = {};
    const now = new Date();
    const ymd = (d) => d.toISOString().slice(0, 10);
    if (period === 'month' && date) {
      const { start, end } = monthRange(date);
      where.date = { [Op.between]: [start, end] };
    } else if (period === 'month') {
      const m = now.toISOString().slice(0, 7);
      where.date = { [Op.between]: [`${m}-01`, `${m}-31`] };
    } else if (period === 'year' && date) {
      where.date = { [Op.gte]: `${date}-01-01`, [Op.lte]: `${date}-12-31` };
    } else if (period === 'year') {
      const y = now.getFullYear();
      where.date = { [Op.gte]: `${y}-01-01`, [Op.lte]: `${y}-12-31` };
    } else if (period === 'all') {
      // no filter
    }
    const total = await Expense.sum('amount', { where }) || 0;
    const count = await Expense.count({ where });
    res.json({ total, count });
  } catch (e) { next(e); }
});

router.get('/category', async (req, res, next) => {
  try {
    const { start, end } = req.query;
    const where = {};
    if (start && end) where.date = { [Op.between]: [start, end] };
    const rows = await Expense.findAll({
      where,
      attributes: ['category', [fn('SUM', col('amount')), 'total'], [fn('COUNT', col('id')), 'count']],
      group: ['category'],
      order: [[literal('total'), 'DESC']],
      raw: true
    });
    res.json(rows);
  } catch (e) { next(e); }
});

router.get('/trend', async (req, res, next) => {
  try {
    const months = parseInt(req.query.months || '6', 10);
    const now = new Date();
    const points = [];
    for (let i = months - 1; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const m = d.toISOString().slice(0, 7);
      const total = await Expense.sum('amount', {
        where: { date: { [Op.between]: [`${m}-01`, `${m}-31`] } }
      }) || 0;
      points.push({ month: m, total: Math.round(total * 100) / 100 });
    }
    res.json(points);
  } catch (e) { next(e); }
});

router.get('/calendar', async (req, res, next) => {
  try {
    const months = parseInt(req.query.months || '6', 10);
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth() - months + 1, 1);
    const startStr = start.toISOString().slice(0, 10);
    const endStr = now.toISOString().slice(0, 10);
    const rows = await Expense.findAll({
      where: { date: { [Op.between]: [startStr, endStr] } },
      attributes: ['date', [fn('SUM', col('amount')), 'total']],
      group: ['date'],
      order: [['date', 'ASC']],
      raw: true
    });
    res.json(rows.map(r => [r.date, Math.round(Number(r.total) * 100) / 100]));
  } catch (e) { next(e); }
});

router.get('/balance', async (req, res, next) => {
  try {
    const { month } = req.query;
    const m = month || new Date().toISOString().slice(0, 7);
    const start = `${m}-01`, end = `${m}-31`;
    const rng = { date: { [Op.between]: [start, end] } };
    const expense = await Expense.sum('amount', { where: rng }) || 0;
    const income = await Income.sum('amount', { where: rng }) || 0;
    res.json({ month: m, expense: Math.round(expense * 100) / 100, income: Math.round(income * 100) / 100, balance: Math.round((income - expense) * 100) / 100 });
  } catch (e) { next(e); }
});

router.get('/motive', async (req, res, next) => {
  try {
    const { start, end } = req.query;
    const where = {};
    if (start && end) where.date = { [Op.between]: [start, end] };
    const rows = await Expense.findAll({
      where,
      attributes: ['motive', [fn('SUM', col('amount')), 'total'], [fn('COUNT', col('id')), 'count']],
      group: ['motive'],
      raw: true
    });
    res.json(rows);
  } catch (e) { next(e); }
});

export default router;