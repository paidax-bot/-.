import { Router } from 'express';
import { Op } from 'sequelize';
import ExcelJS from 'exceljs';
import { Expense } from '../db.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const { start, end, category } = req.query;
    const where = {};
    if (start && end) where.date = { [Op.between]: [start, end] };
    if (category && category !== '全部') where.category = category;
    const rows = await Expense.findAll({ where, order: [['date', 'DESC']], raw: true });

    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet('支出明细');
    ws.columns = [
      { header: '日期', key: 'date', width: 14 },
      { header: '类别', key: 'category', width: 14 },
      { header: '金额(元)', key: 'amount', width: 12 },
      { header: '备注', key: 'note', width: 30 }
    ];
    ws.getRow(1).font = { bold: true };
    rows.forEach(r => ws.addRow(r));
    const total = rows.reduce((s, r) => s + (r.amount || 0), 0);
    ws.addRow({});
    ws.addRow({ date: '合计', amount: total });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=expenses.xlsx');
    await wb.xlsx.write(res);
    res.end();
  } catch (e) { next(e); }
});

export default router;