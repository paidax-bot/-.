import { Router } from 'express';
import { Op } from 'sequelize';
import { Expense, Budget, Income } from '../db.js';

const router = Router();
const EMOTION = ['解压', '冲动', '奖励自己'];

router.get('/', async (req, res, next) => {
  try {
    const month = req.query.month || new Date().toISOString().slice(0, 7);
    const start = `${month}-01`, end = `${month}-31`;
    const rows = await Expense.findAll({ where: { date: { [Op.between]: [start, end] } }, raw: true });
    let total = 0;
    const motiveMap = {};
    rows.forEach(r => { const m = r.motive || '刚需'; motiveMap[m] = (motiveMap[m] || 0) + r.amount; total += r.amount; });
    const ratio = (m) => total > 0 ? (motiveMap[m] || 0) / total : 0;
    const emotionRatio = EMOTION.reduce((s, m) => s + ratio(m), 0);
    const impulseRatio = ratio('冲动') + ratio('奖励自己');
    const needRatio = ratio('刚需');
    const socialRatio = ratio('社交');
    const impulseCount = rows.filter(r => (r.motive === '冲动' || r.motive === '奖励自己')).length;
    const impulseCountRatio = rows.length > 0 ? impulseCount / rows.length : 0;

    const delayScore = Math.round(Math.max(0, Math.min(100, (1 - impulseRatio) * 100)));
    const controlScore = Math.round(Math.max(0, Math.min(100, (1 - impulseCountRatio * 1.5) * 100)));
    const rationalScore = Math.round(Math.max(0, Math.min(100, ((needRatio - emotionRatio) + 1) / 2 * 100)));

    const budgets = await Budget.findAll({ where: { month }, raw: true });
    const totalIncome = await Income.sum('amount', { where: { date: { [Op.between]: [start, end] } } }) || 0;
    let efficacyScore = 60;
    if (budgets.length > 0) {
      let over = 0;
      const catMap = {};
      rows.forEach(r => { catMap[r.category] = (catMap[r.category] || 0) + r.amount; });
      budgets.forEach(b => { if ((catMap[b.category] || 0) > b.limitAmount) over++; });
      efficacyScore = Math.round((1 - over / budgets.length) * 70 + (totalIncome > total ? 30 : 10));
    } else if (totalIncome > 0) {
      efficacyScore = totalIncome > total ? 75 : 50;
    }
    const socialScore = Math.round(Math.max(0, Math.min(100, (1 - socialRatio) * 100)));

    const dimensions = [
      { key: 'delay', name: '延迟满足力', score: delayScore, comment: delayScore >= 80 ? '冲动消费少，延迟满足能力强' : delayScore >= 60 ? '偶有冲动消费，基本能延迟满足' : '冲动消费占比高，延迟满足能力待提升' },
      { key: 'control', name: '冲动控制力', score: controlScore, comment: controlScore >= 80 ? '冲动控制良好' : controlScore >= 60 ? '基本能控制冲动' : '冲动频次高，需加强控制' },
      { key: 'rational', name: '理性消费观', score: rationalScore, comment: rationalScore >= 80 ? '消费理性，刚需为主' : rationalScore >= 60 ? '理性与情绪并存' : '情绪化消费偏多' },
      { key: 'efficacy', name: '财务自我效能', score: efficacyScore, comment: efficacyScore >= 80 ? '财务管理能力强' : efficacyScore >= 60 ? '财务管理一般' : '财务管理待提升' },
      { key: 'social', name: '社交消费独立', score: socialScore, comment: socialScore >= 80 ? '社交消费依赖低' : socialScore >= 60 ? '适度社交消费' : '社交消费占比偏高' }
    ];

    const totalScore = Math.round(delayScore * 0.25 + controlScore * 0.25 + rationalScore * 0.2 + efficacyScore * 0.15 + socialScore * 0.15);
    let grade = 'D', level = '待提升', color = '#ff3366';
    if (totalScore >= 90) { grade = 'S'; level = '卓越'; color = '#00ff88'; }
    else if (totalScore >= 80) { grade = 'A'; level = '优秀'; color = '#00d4ff'; }
    else if (totalScore >= 70) { grade = 'B'; level = '良好'; color = '#ffaa00'; }
    else if (totalScore >= 60) { grade = 'C'; level = '中等'; color = '#ff8800'; }

    const suggestions = [];
    if (delayScore < 70) suggestions.push('冲动/奖励性消费占比偏高，建议购物前设置 24 小时冷静期，训练延迟满足能力');
    if (controlScore < 70) suggestions.push(`本月有 ${impulseCount} 笔冲动消费，建议大额消费前暂停思考"是真的需要还是一时想要"`);
    if (rationalScore < 70) suggestions.push(`情绪化消费（解压+冲动+奖励）占比 ${(emotionRatio * 100).toFixed(0)}%，建议寻找非消费的解压方式如运动、社交、兴趣`);
    if (efficacyScore < 70) suggestions.push('财务自我效能待提升，建议设定预算并坚持执行，培养财务掌控感');
    if (socialScore < 70) suggestions.push('社交消费占比偏高，建议审视是否超出承受范围，学会适度拒绝');
    if (suggestions.length === 0) suggestions.push('消费心理素质良好，保持理性消费习惯与情绪觉察');

    res.json({
      month, total: Math.round(total * 100) / 100, grade, level, color, totalScore,
      dimensions, suggestions,
      emotionRatio: Math.round(emotionRatio * 1000) / 10,
      motiveMap, hasData: total > 0
    });
  } catch (e) { next(e); }
});

export default router;