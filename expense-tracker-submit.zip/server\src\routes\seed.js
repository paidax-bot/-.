import { Router } from 'express';
import { Expense, Budget, Profile, Income } from '../db.js';

const router = Router();

const CATS = ['餐饮', '交通', '学习', '娱乐', '日用品', '通讯', '其他'];
const AMT = { 餐饮: [15, 65], 交通: [2, 30], 学习: [10, 200], 娱乐: [10, 120], 日用品: [5, 80], 通讯: [10, 50], 其他: [5, 100] };
const NOTES = {
  餐饮: ['食堂', '外卖', '聚餐', '早餐', '零食', '夜宵'],
  交通: ['地铁', '公交', '打车', '共享单车', '高铁'],
  学习: ['书', '网课', '文具', '打印', '资料'],
  娱乐: ['电影', '游戏', 'KTV', '奶茶', '剧本杀'],
  日用品: ['纸巾', '洗护', '洗衣液', '电池', '垃圾袋'],
  通讯: ['话费', '流量', '宽带'],
  其他: ['礼物', '杂项', '快递', '维修']
};

function pickCat() {
  const r = Math.random();
  if (r < 0.4) return '餐饮';
  if (r < 0.55) return '娱乐';
  if (r < 0.68) return '日用品';
  if (r < 0.8) return '交通';
  if (r < 0.88) return '学习';
  if (r < 0.95) return '通讯';
  return '其他';
}

function pickMotive(cat) {
  const r = Math.random();
  if (cat === '餐饮') return r < 0.7 ? '刚需' : (r < 0.9 ? '社交' : '解压');
  if (cat === '交通') return '刚需';
  if (cat === '学习') return r < 0.7 ? '刚需' : '改善生活';
  if (cat === '娱乐') return r < 0.4 ? '解压' : (r < 0.7 ? '冲动' : (r < 0.9 ? '奖励自己' : '社交'));
  if (cat === '日用品') return '刚需';
  if (cat === '通讯') return '刚需';
  return r < 0.5 ? '刚需' : (r < 0.8 ? '改善生活' : '冲动');
}

router.post('/', async (req, res, next) => {
  try {
    await Expense.destroy({ where: {}, truncate: true });
    await Budget.destroy({ where: {}, truncate: true });

    const now = new Date();
    for (let i = 2; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const y = d.getFullYear(), m = d.getMonth();
      const daysInMonth = new Date(y, m + 1, 0).getDate();
      const lastDay = (i === 0) ? now.getDate() : daysInMonth;
      const mealNotes = ['早餐', '午餐', '晚餐', '夜宵'];
      for (let day = 1; day <= lastDay; day++) {
        const meals = 1 + Math.floor(Math.random() * 2);
        for (let k = 0; k < meals; k++) {
          const amt = Math.round((12 + Math.random() * 40) * 100) / 100;
          const date = `${y}-${String(m + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const note = mealNotes[Math.floor(Math.random() * mealNotes.length)];
          await Expense.create({ category: '餐饮', amount: amt, date, note, motive: pickMotive('餐饮') });
        }
      }
      const extra = 15 + Math.floor(Math.random() * 10);
      for (let j = 0; j < extra; j++) {
        const cat = pickCat();
        const [lo, hi] = AMT[cat];
        const amt = Math.round((lo + Math.random() * (hi - lo)) * 100) / 100;
        const day = 1 + Math.floor(Math.random() * lastDay);
        const date = `${y}-${String(m + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const note = NOTES[cat][Math.floor(Math.random() * NOTES[cat].length)];
        await Expense.create({ category: cat, amount: amt, date, note, motive: pickMotive(cat) });
      }
    }

    const curMonth = now.toISOString().slice(0, 7);
    const TPL = { 餐饮: 42, 交通: 7, 学习: 12, 娱乐: 10, 日用品: 10, 通讯: 4, 其他: 5 };
    for (const c of CATS) {
      await Budget.create({ category: c, month: curMonth, limitAmount: Math.round(TPL[c] / 100 * 1700 * 100) / 100 });
    }

    let p = await Profile.findOne();
    if (!p) p = await Profile.create({});
    await p.update({ monthIncome: 2000, savingsGoal: 300, peerAvg: 1800, style: '标准型' });

    res.json({ ok: true, msg: '示例数据已导入' });
  } catch (e) { next(e); }
});

router.delete('/', async (req, res, next) => {
  try {
    await Expense.destroy({ where: {}, truncate: true });
    await Budget.destroy({ where: {}, truncate: true });
    await Income.destroy({ where: {}, truncate: true });
    let p = await Profile.findOne();
    if (!p) p = await Profile.create({});
    await p.update({ monthIncome: 2000, savingsGoal: 300, peerAvg: 1800, style: '标准型' });
    res.json({ ok: true, msg: '已清空' });
  } catch (e) { next(e); }
});

export default router;