<template>
  <div class="layout">
    <!-- 侧边栏 -->
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-logo">◢◣</div>
        <div class="brand-text">
          <div class="glitch font-display" data-text="NEON">NEON</div>
          <div class="brand-sub font-label">LEDGER v1.0</div>
        </div>
      </div>

      <nav class="nav">
        <router-link v-for="m in menus" :key="m.path" :to="m.path" class="nav-item" active-class="active">
          <span class="nav-idx">{{ m.idx }}</span>
          <span class="nav-icon">{{ m.icon }}</span>
          <span class="nav-label">{{ m.label }}</span>
        </router-link>
      </nav>

      <div class="sidebar-foot">
        <div class="sys-line"><span class="dot ok"></span>SYSTEM ONLINE</div>
        <div class="sys-line font-label">DB :: SQLITE</div>
        <div class="sys-line font-label">NODE :: {{ clock }}</div>
      </div>
    </aside>

    <!-- 主区 -->
    <div class="main">
      <header class="topbar">
        <div class="topbar-left">
          <span class="label-tag">{{ currentLabel }}</span>
          <span class="topbar-path font-mono">~/ledger/{{ $route.name }}</span>
        </div>
        <div class="topbar-right">
          <span class="status-lamp"></span>
          <span class="font-label neon-cyan">SECURE LINK</span>
          <span class="topbar-sep">|</span>
          <span class="font-mono muted-fg">{{ dateStr }}</span>
        </div>
      </header>

      <main class="content">
        <router-view v-slot="{ Component }">
          <transition name="page" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </main>

      <footer class="footbar font-label">
        <span>© 2077 NEON LEDGER</span>
        <span class="foot-mid">// CYBER EXPENSE TRACKER //</span>
        <span>ENCRYPTED&nbsp;<span class="neon">●</span></span>
      </footer>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { useRoute } from 'vue-router';

const route = useRoute();
const menus = [
  { path: '/', idx: '01', icon: '◈', label: '控制台' },
  { path: '/record', idx: '02', icon: '✚', label: '记账' },
  { path: '/stats', idx: '03', icon: '▤', label: '统计' },
  { path: '/budget', idx: '04', icon: '⬚', label: '预算' },
  { path: '/plan', idx: '05', icon: '⌬', label: '规划' },
  { path: '/assessment', idx: '06', icon: '★', label: '测评' },
  { path: '/goal', idx: '07', icon: '◎', label: '目标' },
  { path: '/mind', idx: '08', icon: '◉', label: '心理' },
  { path: '/wishlist', idx: '09', icon: '✦', label: '心愿' }
];
const currentLabel = computed(() => menus.find(m => m.path === route.path)?.label || 'SYSTEM');

const clock = ref('');
const dateStr = ref('');
let timer = null;
function tick() {
  const d = new Date();
  clock.value = d.toTimeString().slice(0, 8);
  dateStr.value = d.toISOString().slice(0, 10) + ' ' + d.toTimeString().slice(0, 8);
}
onMounted(() => { tick(); timer = setInterval(tick, 1000); });
onUnmounted(() => clearInterval(timer));
</script>

<style scoped>
.layout { display: flex; min-height: 100vh; }

/* 侧边栏 */
.sidebar {
  width: 230px;
  flex-shrink: 0;
  background: linear-gradient(180deg, #0c0c14, #08080e);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  position: relative;
}
.sidebar::after {
  content: "";
  position: absolute;
  top: 0; right: 0; bottom: 0;
  width: 1px;
  background: linear-gradient(180deg, transparent, var(--accent), transparent);
  opacity: .4;
}
.brand { padding: 22px 18px; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 12px; }
.brand-logo { color: var(--accent); font-size: 22px; text-shadow: var(--glow); animation: flicker 4s infinite; }
.brand-text .glitch { font-size: 20px; font-weight: 900; }
.brand-sub { color: var(--muted-fg); font-size: 11px; margin-top: 2px; }

.nav { padding: 16px 0; flex: 1; }
.nav-item {
  display: flex; align-items: center; gap: 12px;
  padding: 13px 18px;
  color: var(--muted-fg);
  font-family: "Share Tech Mono", monospace;
  letter-spacing: .06em;
  border-left: 2px solid transparent;
  transition: all .18s;
  position: relative;
}
.nav-item:hover { color: var(--accent); background: rgba(0,255,136,.06); }
.nav-item.active {
  color: var(--accent);
  background: linear-gradient(90deg, rgba(0,255,136,.14), transparent);
  border-left-color: var(--accent);
  box-shadow: inset 0 0 16px rgba(0,255,136,.08);
}
.nav-item.active::after { content: "◄"; position: absolute; right: 14px; color: var(--accent); font-size: 10px; }
.nav-idx { font-size: 11px; color: var(--accent-3); opacity: .7; }
.nav-icon { font-size: 16px; width: 18px; text-align: center; }
.nav-label { font-size: 14px; }

.sidebar-foot { padding: 16px 18px; border-top: 1px solid var(--border); }
.sys-line { font-size: 11px; color: var(--muted-fg); margin: 5px 0; display: flex; align-items: center; gap: 6px; }
.dot { width: 7px; height: 7px; border-radius: 50%; display: inline-block; }
.dot.ok { background: var(--accent); box-shadow: var(--glow); animation: pulse-glow 2s infinite; }

/* 主区 */
.main { flex: 1; display: flex; flex-direction: column; min-width: 0; }
.topbar {
  height: 56px;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 26px;
  background: rgba(12,12,20,.7);
  backdrop-filter: blur(6px);
  border-bottom: 1px solid var(--border);
}
.topbar-left { display: flex; align-items: center; gap: 14px; }
.topbar-path { color: var(--muted-fg); font-size: 13px; }
.topbar-right { display: flex; align-items: center; gap: 10px; font-size: 12px; }
.status-lamp { width: 8px; height: 8px; border-radius: 50%; background: var(--accent); box-shadow: var(--glow); animation: pulse-glow 1.6s infinite; }
.topbar-sep { color: var(--border); }
.muted-fg { color: var(--muted-fg); }

.content { flex: 1; padding: 26px; overflow-y: auto; }

.footbar {
  display: flex; justify-content: space-between; align-items: center;
  padding: 10px 26px;
  border-top: 1px solid var(--border);
  background: #08080e;
  color: var(--muted-fg);
  font-size: 11px;
}
.foot-mid { color: var(--accent-3); opacity: .6; }

/* 页面切换动画 */
.page-enter-active, .page-leave-active { transition: opacity .25s, transform .25s; }
.page-enter-from { opacity: 0; transform: translateY(10px); }
.page-leave-to { opacity: 0; transform: translateY(-10px); }

@media (max-width: 760px) {
  .sidebar { width: 64px; }
  .brand-text, .nav-label, .nav-idx, .sidebar-foot, .brand-sub { display: none; }
  .nav-item { justify-content: center; }
}
</style>