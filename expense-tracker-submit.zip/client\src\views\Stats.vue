<template>
  <div class="stats-page">
    <div class="page-head">
      <div>
        <div class="page-eyebrow font-label">// ANALYTICS CORE</div>
        <h1 class="page-title font-display">统计</h1>
      </div>
      <div class="period-sel">
        <el-radio-group v-model="period" @change="onPeriodChange">
          <el-radio-button label="month">月</el-radio-button>
          <el-radio-button label="year">年</el-radio-button>
          <el-radio-button label="all">全部</el-radio-button>
        </el-radio-group>
        <el-date-picker v-if="period==='month'" v-model="month" type="month" format="YYYY-MM" value-format="YYYY-MM" @change="load" />
        <el-date-picker v-else-if="period==='year'" v-model="year" type="year" format="YYYY" value-format="YYYY" @change="load" />
      </div>
    </div>

    <div class="tiles">
      <div class="stat-tile tile">
        <div class="tile-label font-label">总支出</div>
        <div class="tile-value neon">¥{{ fmt(summary.total) }}</div>
      </div>
      <div class="stat-tile tile">
        <div class="tile-label font-label">笔数</div>
        <div class="tile-value neon-cyan">{{ summary.count }}</div>
      </div>
      <div class="stat-tile tile">
        <div class="tile-label font-label">最高类别</div>
        <div class="tile-value neon-pink">{{ topCat?.category || '—' }}</div>
        <div class="tile-foot font-mono">{{ topCat ? '¥' + fmt(topCat.total) : '' }}</div>
      </div>
      <div class="stat-tile tile">
        <div class="tile-label font-label">类别数</div>
        <div class="tile-value" style="color:var(--accent-3)">{{ catData.length }}</div>
      </div>
    </div>

    <div class="charts">
      <div class="cyber-panel chart-box">
        <div class="panel-head"><span class="label-tag">BAR</span><span class="panel-title font-display">类别支出</span></div>
        <div ref="barEl" class="chart-canvas"></div>
      </div>
      <div class="cyber-panel chart-box">
        <div class="panel-head"><span class="label-tag">LINE</span><span class="panel-title font-display">月度趋势</span></div>
        <div ref="lineEl" class="chart-canvas"></div>
      </div>
    </div>

    <div class="cyber-panel rank-panel">
      <div class="panel-head"><span class="label-tag">RANK</span><span class="panel-title font-display">类别排行</span></div>
      <el-table :data="catData" style="width:100%" empty-text="// NO DATA">
        <el-table-column label="排名" type="index" width="80" />
        <el-table-column label="类别" prop="category" width="140">
          <template #default="{ row }"><span class="cell-cat" :style="{ color: catColor(row.category) }">{{ row.category }}</span></template>
        </el-table-column>
        <el-table-column label="金额" width="160">
          <template #default="{ row }"><span class="cell-amt">¥{{ fmt(row.total) }}</span></template>
        </el-table-column>
        <el-table-column label="笔数" prop="count" width="120" />
        <el-table-column label="占比" width="200">
          <template #default="{ row }">
            <div class="rank-bar"><div class="rank-fill" :style="{ width: pct(row.total) + '%', background: catColor(row.category) }"></div></div>
            <span class="font-mono" style="color:var(--muted-fg);font-size:12px">{{ pct(row.total) }}%</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted, nextTick } from 'vue';
import { statsApi, CATEGORIES } from '../api/index.js';
import { makeChart, NEON_COLORS, axisStyle, tooltipStyle, neonLineSeries } from '../utils/chart.js';
import * as echarts from 'echarts';

const fmt = (n) => (Number(n) || 0).toFixed(2);
const catColor = (c) => NEON_COLORS[CATEGORIES.indexOf(c) % NEON_COLORS.length] || '#00ff88';

const period = ref('month');
const month = ref(new Date().toISOString().slice(0, 7));
const year = ref(String(new Date().getFullYear()));
const summary = reactive({ total: 0, count: 0 });
const catData = ref([]);
const trendData = ref([]);

const barEl = ref(null), lineEl = ref(null);
let barChart = null, lineChart = null;

const topCat = computed(() => catData.value[0] || null);
const pct = (v) => summary.total ? Math.round(v / summary.total * 100) : 0;

function range() {
  if (period.value === 'month') return { start: `${month.value}-01`, end: `${month.value}-31` };
  if (period.value === 'year') return { start: `${year.value}-01-01`, end: `${year.value}-12-31` };
  return {};
}

function onPeriodChange() { load(); }

async function load() {
  const r = range();
  const sumParams = period.value === 'all' ? { period: 'all' } : { period: period.value, date: period.value === 'month' ? month.value : year.value };
  const [s, c, t] = await Promise.all([
    statsApi.summary(sumParams),
    statsApi.category(r),
    statsApi.trend({ months: 6 })
  ]);
  summary.total = s.total; summary.count = s.count;
  catData.value = c; trendData.value = t;
  await nextTick();
  renderBar(); renderLine();
}

function renderBar() {
  if (!barEl.value) return;
  if (!barChart) barChart = makeChart(barEl.value);
  const cats = catData.value.map(d => d.category);
  const vals = catData.value.map(d => Number(d.total));
  barChart.chart.setOption({
    tooltip: { trigger: 'axis', ...tooltipStyle },
    grid: { left: 50, right: 20, top: 20, bottom: 30 },
    xAxis: { type: 'category', data: cats, ...axisStyle },
    yAxis: { type: 'value', ...axisStyle },
    series: [{
      type: 'bar', data: vals.map((v, i) => ({ value: v, itemStyle: { color: NEON_COLORS[i % NEON_COLORS.length], shadowColor: NEON_COLORS[i % NEON_COLORS.length], shadowBlur: 8 } })),
      barWidth: '55%',
      itemStyle: { borderRadius: [2, 2, 0, 0] }
    }]
  }, true);
}

function renderLine() {
  if (!lineEl.value) return;
  if (!lineChart) lineChart = makeChart(lineEl.value);
  lineChart.chart.setOption({
    tooltip: { trigger: 'axis', ...tooltipStyle },
    grid: { left: 50, right: 20, top: 20, bottom: 30 },
    xAxis: { type: 'category', data: trendData.value.map(d => d.month), ...axisStyle },
    yAxis: { type: 'value', ...axisStyle },
    series: [neonLineSeries({ data: trendData.value.map(d => d.total) })]
  }, true);
}

onMounted(load);
onUnmounted(() => { barChart?.dispose(); lineChart?.dispose(); });
</script>

<style scoped>
.stats-page { display: flex; flex-direction: column; gap: 20px; }
.page-head { display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 12px; }
.page-eyebrow { color: var(--accent-3); font-size: 12px; }
.page-title { font-size: 26px; font-weight: 900; color: var(--fg); margin: 4px 0 0; }
.period-sel { display: flex; gap: 10px; align-items: center; }

.tiles { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
.tile { padding: 20px; }
.tile-label { color: var(--muted-fg); font-size: 11px; }
.tile-value { font-family: "Orbitron", monospace; font-size: 26px; font-weight: 700; margin: 8px 0 4px; }
.tile-foot { color: var(--muted-fg); font-size: 11px; }

.charts { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.chart-box { padding: 16px; }
.panel-head { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
.panel-title { color: var(--fg); font-size: 15px; }
.chart-canvas { width: 100%; height: 300px; }

.rank-panel { padding: 18px; }
.cell-cat { font-family: "Share Tech Mono", monospace; }
.cell-amt { color: var(--accent); font-weight: 700; }
.rank-bar { height: 6px; background: var(--muted); margin-bottom: 4px; overflow: hidden; }
.rank-fill { height: 100%; box-shadow: 0 0 6px currentColor; }

@media (max-width: 980px) { .tiles { grid-template-columns: repeat(2,1fr); } .charts { grid-template-columns: 1fr; } }
</style>