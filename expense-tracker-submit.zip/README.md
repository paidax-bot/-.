# NEON LEDGER · 赛博记账

> 一个赛博朋克风格的大学生消费心理成长工具——不止记账，更帮你理解每一笔消费背后的心理动机。

前后端分离架构，数据持久化到 SQLite，单人使用版（无需登录注册）。

---

## ✨ 功能总览

| 序号 | 页面 | 路由 | 核心功能 |
|:---:|------|------|----------|
| 01 | 控制台 | `/` | 月度概览卡片（数字滚动动画）、预算使用率、近 6 月趋势折线、类别占比饼图、消费日历热力图、预算执行条、最近记录、超支警报、数据备份/恢复 |
| 02 | 记账 | `/record` | 支出/收入切换录入、消费动机标签（刚需/改善/社交/解压/冲动/奖励）、编辑/删除、按日期与类别筛选、分页、导出 Excel |
| 03 | 统计 | `/stats` | 月/年/全部周期切换、类别柱状图、月度趋势折线、类别排行表、消费动机占比分析 |
| 04 | 预算 | `/budget` | 按类别设定月度预算、执行进度条、超支预警、删除预算 |
| 05 | 规划 | `/plan` | 三套消费比例模板（节俭型/标准型/品质型）、基于近 3 月历史微调、一键应用为预算、储蓄可达性分析 |
| 06 | 测评 | `/assessment` | 五维评分（合理性/节俭度/均衡性/计划性/储蓄率）、雷达图、S/A/B/C/D 等级徽章、个性化改进建议 |
| 07 | 目标 | `/goal` | 存钱目标进度环、已存/剩余/每日应存额、预计达成日期推算 |
| 08 | 心理 | `/mind` | 消费心理测评（延迟满足力/冲动控制力/理性消费观/财务自我效能/社交独立）、情绪消费占比、等级徽章、雷达图 |
| 09 | 心愿 | `/wishlist` | 想要清单、冷静期倒计时、状态徽章（冷静中/已通过/已购买）、冷静通过率统计 |

### 亮点功能
- **消费动机标签**：每笔支出标注心理动机，统计情绪消费占比
- **消费心理测评**：5 维度量化分析 + 雷达图 + 等级 + 建议
- **冷静期管理**：想要清单加冷静期，避免冲动消费
- **存钱目标追踪**：进度环 + 智能推算达成日期
- **数据安全**：一键备份 JSON / 导入恢复，演示不丢真实数据

---

## 🛠 技术栈

| 层 | 技术 |
|------|------|
| 前端 | Vue 3 + Vite + Element Plus + ECharts + Vue Router |
| 后端 | Node.js + Express + Sequelize + SQLite |
| 主题 | Cyberpunk 赛博朋克（霓虹绿 #00ff88 / 品红 #ff00ff / 青色 #00d4ff，深黑底，扫描线 + 网格 + Glitch 动画） |

---

## 📋 环境要求

- **Node.js 18 及以上**（推荐 20+，自带 npm）
  - 下载地址：https://nodejs.org/（选 LTS 版本）
  - 验证安装：终端输入 `node -v` 和 `npm -v` 能看到版本号即可

---

## 🚀 安装与运行

### Windows（推荐用 cmd 命令提示符，不用 PowerShell）

```bash
# 第 1 步：启动后端（端口 3000）
cd expense-tracker/server
npm install
npm start

# 第 2 步：新开一个 cmd 窗口，启动前端（端口 5173）
cd expense-tracker/client
npm install
npm run dev
```

### macOS / Linux

```bash
# 第 1 步：启动后端
cd expense-tracker/server
npm install
npm start

# 第 2 步：新开一个终端窗口，启动前端
cd expense-tracker/client
npm install
npm run dev
```

### 第 3 步：打开浏览器

启动成功后，浏览器访问：

```
http://localhost:5173
```

即可看到网站首页（赛博朋克风格控制台）。

### 第 4 步（可选）：导入演示数据

首次打开时页面是空的，点击控制台页的 **「载入示例数据」** 按钮，一键生成 3 个月的模拟消费数据（含餐饮/交通/学习等多类别 + 动机标签），所有图表立即有内容展示。

---

## 📁 目录结构

```
expense-tracker/
├── README.md                 本文件
├── server/                   后端（Express + SQLite）
│   ├── package.json
│   └── src/
│       ├── app.js            Express 入口，挂载全部 13 个路由
│       ├── db.js             Sequelize + 6 个数据模型
│       └── routes/
│           ├── expense.js    支出 CRUD
│           ├── stats.js      统计分析（含动机占比）
│           ├── budget.js     预算管理
│           ├── export.js     Excel 导出
│           ├── profile.js    消费画像
│           ├── plan.js       花销规划
│           ├── assessment.js 花销测评
│           ├── seed.js       演示数据导入/清空
│           ├── income.js     收入管理
│           ├── backup.js     数据备份/恢复
│           ├── goal.js       存钱目标
│           ├── mind.js       消费心理测评
│           └── wishlist.js   想要清单+冷静期
├── client/                   前端（Vue 3 + Vite）
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   └── src/
│       ├── main.js
│       ├── App.vue
│       ├── router/index.js
│       ├── api/index.js      全部 API 封装 + 常量定义
│       ├── styles/
│       │   └── cyberpunk.css 赛博主题 + Element Plus 深度定制
│       ├── utils/
│       │   └── chart.js      ECharts 赛博配色
│       ├── components/
│       │   ├── CountUp.vue   数字滚动动画
│       │   └── EmptyState.vue 空状态组件
│       └── views/
│           ├── Dashboard.vue  控制台
│           ├── Record.vue     记账
│           ├── Stats.vue      统计
│           ├── Budget.vue     预算
│           ├── Plan.vue       规划
│           ├── Assessment.vue 测评
│           ├── Goal.vue       目标
│           ├── Mind.vue       心理
│           └── Wishlist.vue   心愿
```

---

## 🗃 数据说明

- 数据库文件 `server/data.db` 在**首次启动后端时自动生成**，无需手动创建
- 包含 6 张表：`expenses`（支出）、`incomes`（收入）、`budgets`（预算）、`profiles`（消费画像）、`goals`（存钱目标）、`wishlists`（想要清单）
- **数据备份**：控制台页可一键导出 JSON 备份文件，也可导入恢复
- **清空数据**：控制台页有「清空数据」按钮，一键清空所有支出/收入/预算

---

## 🔧 常见问题

### Q: `npm install` 很慢或失败？
国内网络建议先切换淘宝镜像源：
```bash
npm config set registry https://registry.npmmirror.com
```
然后重新执行 `npm install`。

### Q: PowerShell 运行 npm 报错「无法加载文件，因为在此系统上禁止运行脚本」？
改用 **cmd（命令提示符）** 而非 PowerShell。Win+R 输入 `cmd` 回车即可打开。

### Q: 启动后端报 `EADDRINUSE: address already in use :::3000`？
端口 3000 被占用。关掉其他占用该端口的进程，或修改 `server/src/app.js` 最后一行的 `PORT` 值。

### Q: 前端页面打开是空白的？
检查后端是否成功启动（终端应显示 `[SERVER] http://localhost:3000`）。前端依赖后端 API，后端没启动则页面空白。

### Q: sqlite3 安装编译失败？
确保 Node.js 版本 ≥ 18。Windows 用户需安装 Visual Studio Build Tools（`npm install -g windows-build-tools`）或使用 Node.js LTS 版本。

---

## 🎨 设计说明

- **配色**：霓虹绿 `#00ff88` / 品红 `#ff00ff` / 青色 `#00d4ff`，深黑底 `#0a0e1a`
- **字体**：Orbitron（标题）+ JetBrains Mono（数据）+ 系统字体（正文）
- **动效**：扫描线背景、网格底纹、Glitch 文字、数字滚动、卡片悬浮扫描线、边框流动光效
- **响应式**：适配桌面 / 平板 / 手机

---

## 📝 版本

- **v1.0** — 9 个页面 + 精细化打磨完成