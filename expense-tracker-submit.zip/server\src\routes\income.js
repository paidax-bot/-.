import { Router } from 'express';
import { Op } from 'sequelize';
import { Income } from '../db.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const { start, end, source } = req.query;
    const where = {};
    if (start && end) where.date = { [Op.between]: [start, end] };
    else if (start) where.date = { [Op.gte]: start };
    else if (end) where.date = { [Op.lte]: end };
    if (source && source !== '全部') where.source = source;
    const rows = await Income.findAll({ where, order: [['date', 'DESC'], ['created_at', 'DESC']] });
    res.json(rows);
  } catch (e) { next(e); }
});

router.post('/', async (req, res, next) => {
  try { res.json(await Income.create(req.body)); } catch (e) { next(e); }
});

router.put('/:id', async (req, res, next) => {
  try {
    const r = await Income.findByPk(req.params.id);
    if (!r) return res.status(404).json({ error: 'not found' });
    await r.update(req.body);
    res.json(r);
  } catch (e) { next(e); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    const r = await Income.findByPk(req.params.id);
    if (!r) return res.status(404).json({ error: 'not found' });
    await r.destroy();
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default router;