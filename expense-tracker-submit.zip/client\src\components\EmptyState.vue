<template>
  <div class="empty-state-cyber">
    <div class="es-icon">{{ icon }}</div>
    <div class="es-text font-label">// {{ text }}</div>
    <div v-if="hint" class="es-hint font-mono">{{ hint }}</div>
  </div>
</template>

<script setup>
defineProps({
  icon: { type: String, default: '⊘' },
  text: { type: String, default: '暂无数据' },
  hint: { type: String, default: '' }
});
</script>

<style scoped>
.empty-state-cyber { padding: 48px 20px; text-align: center; }
.es-icon { font-size: 52px; color: var(--muted-fg); opacity: .6; animation: flicker 4s infinite; }
.es-text { color: var(--accent-3); font-size: 14px; margin-top: 14px; letter-spacing: .1em; }
.es-hint { color: var(--muted-fg); font-size: 12px; margin-top: 8px; }
</style>