import { Sequelize, DataTypes } from 'sequelize';
import { fileURLToPath } from 'url';
import path from 'path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, '..', 'data.db');

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: dbPath,
  logging: false
});

export const Expense = sequelize.define('Expense', {
  category: { type: DataTypes.STRING, allowNull: false },
  amount: { type: DataTypes.FLOAT, allowNull: false },
  date: { type: DataTypes.STRING, allowNull: false },
  note: { type: DataTypes.STRING, defaultValue: '' },
  motive: { type: DataTypes.STRING, defaultValue: '刚需' }
}, { timestamps: true, underscored: true });

export const Budget = sequelize.define('Budget', {
  category: { type: DataTypes.STRING, allowNull: false },
  month: { type: DataTypes.STRING, allowNull: false },
  limitAmount: { type: DataTypes.FLOAT, allowNull: false }
}, { timestamps: true, underscored: true });

export const Profile = sequelize.define('Profile', {
  monthIncome: { type: DataTypes.FLOAT, defaultValue: 0 },
  savingsGoal: { type: DataTypes.FLOAT, defaultValue: 0 },
  style: { type: DataTypes.STRING, defaultValue: '标准型' },
  peerAvg: { type: DataTypes.FLOAT, defaultValue: 1800 }
}, { timestamps: true, underscored: true });

export const Income = sequelize.define('Income', {
  source: { type: DataTypes.STRING, allowNull: false },
  amount: { type: DataTypes.FLOAT, allowNull: false },
  date: { type: DataTypes.STRING, allowNull: false },
  note: { type: DataTypes.STRING, defaultValue: '' }
}, { timestamps: true, underscored: true });

export const Goal = sequelize.define('Goal', {
  name: { type: DataTypes.STRING, defaultValue: '存钱目标' },
  targetAmount: { type: DataTypes.FLOAT, allowNull: false },
  deadline: { type: DataTypes.STRING, allowNull: false }
}, { timestamps: true, underscored: true });

export const Wishlist = sequelize.define('Wishlist', {
  name: { type: DataTypes.STRING, allowNull: false },
  price: { type: DataTypes.FLOAT, defaultValue: 0 },
  coolDays: { type: DataTypes.INTEGER, defaultValue: 7 },
  addedDate: { type: DataTypes.STRING, allowNull: false },
  status: { type: DataTypes.STRING, defaultValue: 'cooling' }
}, { timestamps: true, underscored: true });

export async function initDB() {
  await sequelize.sync({ alter: true });
  console.log('[DB] SQLite ready ->', dbPath);
}

export default sequelize;