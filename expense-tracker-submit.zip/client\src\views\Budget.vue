<template>
  <div class="budget-page">
    <div class="page-head">
      <div>
        <div class="page-eyebrow font-label">// CREDIT LIMIT CONTROL</div>
        <h1 class="page-title font-display">预算</h1>
      </div>
      <el-date-picker v-model="month" type="month" format="YYYY-MM" value-format="YYYY-MM" :clearable="false" @change="load" />
    </div>

    <div class="tiles">
      <div class="stat-tile tile">
        <div class="tile-label font-label">总预算</div>
        <div class="tile-value neon-cyan">¥{{ fmt(totalLimit) }}</div>
      </div>
      <div class="stat-tile tile">
        <div class="tile-label font-label">本月已用</div>
        <div class="tile-value neon">¥{{ fmt(totalUsed) }}</div>
      </div>
      <div class="stat-tile tile">
        <div class="tile-label font-label">剩余</div>
        <div class="tile-value" :class="remain < 0 ? 'neon-pink' : 'neon'">¥{{ fmt(remain) }}</div>
      </div>
      <div class="stat-tile tile">
        <div class="tile-label font-label">使用率</div>
        <div class="tile-value" :class="rate > 100 ? 'neon-pink' : 'neon-cyan'">{{ rate }}%</div>
      </div>
    </div>

    <div class="budget-grid">
      <!-- 设置表单 -->
      <div class="cyber-panel form-panel">
        <div class="panel-head"><span class="label-tag">SET</span><span class="panel-title font-display">设定预算</span></div>
        <el-form label-position="top">
          <el-form-item label="类别">
            <el-select v-model="form.category" style="width:100%">
              <el-option v-for="c in CATEGORIES" :key="c" :label="c" :value="c" />
            </el-select>
          </el-form-item>
          <el-form-item label="月度限额 / CNY">
            <el-input v-model.number="form.limit" type="number" placeholder="0.00">
              <template #prefix><span class="neon">¥</span></template>
            </el-input>
          </el-form-item>
          <el-button type="primary" @click="setBudget" style="width:100%">写入限额</el-button>
        </el-form>
        <div class="hint font-label">// 同类别同月份将覆盖更新</div>
      </div>

      <!-- 预算列表 -->
      <div class="cyber-panel list-panel">
        <div class="panel-head"><span class="label-tag">STATUS</span><span class="panel-title font-display">执行状态 · {{ month }}</span></div>
        <div class="b-list">
          <div v-for="b in view" :key="b.category" class="b-card">
            <div class="b-top">
              <span class="b-cat font-label" :style="{ color: catColor(b.category) }">{{ b.category }}</span>
              <span class="b-amt font-mono">¥{{ fmt(b.used) }} / ¥{{ fmt(b.limit) }}</span>
              <el-button size="small" type="danger" @click="remove(b)">删除</el-button>
            </div>
            <div class="b-bar">
              <div class="b-fill" :style="{ width: b.pct + '%', background: b.over ? 'linear-gradient(90deg,#ff3366,#ff00ff)' : 'linear-gradient(90deg,#00ff88,#00d4ff)' }"></div>
            </div>
            <div class="b-status font-label" :class="b.over ? 'over' : 'ok'">
              {{ b.over ? '⚠ OVER LIMIT · 超支 ¥' + fmt(b.used - b.limit) : '● SAFE · 剩余 ¥' + fmt(b.limit - b.used) }}
            </div>
          </div>
          <div v-if="!view.length" class="empty font-label">// 暂未设定预算，左侧表单写入限额</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { budgetApi, statsApi, CATEGORIES } from '../api/index.js';
import { NEON_COLORS } from '../utils/chart.js';

const fmt = (n) => (Number(n) || 0).toFixed(2);
const catColor = (c) => NEON_COLORS[CATEGORIES.indexOf(c) % NEON_COLORS.length] || '#00ff88';

const month = ref(new Date().toISOString().slice(0, 7));
const form = reactive({ category: '餐饮', limit: null });
const budgets = ref([]);
const usedMap = ref({});

const totalLimit = computed(() => budgets.value.reduce((s, b) => s + Number(b.limitAmount), 0));
const totalUsed = computed(() => budgets.value.reduce((s, b) => s + (usedMap.value[b.category] || 0), 0));
const remain = computed(() => totalLimit.value - totalUsed.value);
const rate = computed(() => totalLimit.value ? Math.round(totalUsed.value / totalLimit.value * 100) : 0);

const view = computed(() => budgets.value.map(b => {
  const used = usedMap.value[b.category] || 0;
  const pct = Math.min(100, Math.round(used / b.limitAmount * 100));
  return { id: b.id, category: b.category, limit: b.limitAmount, used, pct, over: used > b.limitAmount };
}));

async function load() {
  const start = `${month.value}-01`, end = `${month.value}-31`;
  const [b, c] = await Promise.all([
    budgetApi.list({ month: month.value }),
    statsApi.category({ start, end })
  ]);
  budgets.value = b;
  const m = {};
  c.forEach(item => { m[item.category] = Number(item.total); });
  usedMap.value = m;
}

async function setBudget() {
  if (!form.limit || Number(form.limit) <= 0) return ElMessage.warning('请输入有效限额');
  await budgetApi.set({ category: form.category, month: month.value, limitAmount: Number(form.limit) });
  ElMessage.success(`${form.category} 预算已设定`);
  form.limit = null;
  await load();
}

async function remove(b) {
  await ElMessageBox.confirm(`删除 ${b.category} 的预算?`, '确认', { type: 'warning' });
  await budgetApi.remove(b.id);
  ElMessage.success('已删除');
  await load();
}

onMounted(load);
</script>

<style scoped>
.budget-page { display: flex; flex-direction: column; gap: 20px; }
.page-head { display: flex; justify-content: space-between; align-items: flex-end; }
.page-eyebrow { color: var(--accent-3); font-size: 12px; }
.page-title { font-size: 26px; font-weight: 900; color: var(--fg); margin: 4px 0 0; }

.tiles { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
.tile { padding: 20px; }
.tile-label { color: var(--muted-fg); font-size: 11px; }
.tile-value { font-family: "Orbitron", monospace; font-size: 26px; font-weight: 700; margin: 8px 0 4px; }

.budget-grid { display: grid; grid-template-columns: 320px 1fr; gap: 16px; align-items: start; }
.form-panel { padding: 18px; position: sticky; top: 0; }
.panel-head { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
.panel-title { color: var(--fg); font-size: 15px; }
.hint { color: var(--muted-fg); font-size: 11px; margin-top: 12px; text-align: center; }

.list-panel { padding: 18px; }
.b-list { display: flex; flex-direction: column; gap: 14px; }
.b-card { background: var(--bg-2); border: 1px solid var(--border); border-left: 3px solid var(--accent); padding: 14px 16px; }
.b-top { display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }
.b-cat { font-size: 14px; flex: 1; }
.b-amt { color: var(--fg); font-size: 13px; }
.b-bar { height: 8px; background: var(--muted); overflow: hidden; }
.b-fill { height: 100%; transition: width .5s; box-shadow: 0 0 8px rgba(0,255,136,.4); }
.b-status { font-size: 11px; margin-top: 8px; }
.b-status.ok { color: var(--accent); }
.b-status.over { color: var(--destructive); }
.empty { color: var(--muted-fg); font-size: 12px; padding: 24px; text-align: center; }

@media (max-width: 980px) { .tiles { grid-template-columns: repeat(2,1fr); } .budget-grid { grid-template-columns: 1fr; } .form-panel { position: static; } }
</style>