import { Router } from 'express';
import { Expense, Budget, Income, Profile } from '../db.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    const expenses = await Expense.findAll({ raw: true });
    const budgets = await Budget.findAll({ raw: true });
    const incomes = await Income.findAll({ raw: true });
    const profile = await Profile.findOne({ raw: true });
    res.json({ version: 1, exportDate: new Date().toISOString(), expenses, budgets, incomes, profile });
  } catch (e) { next(e); }
});

router.post('/restore', async (req, res, next) => {
  try {
    const { expenses = [], budgets = [], incomes = [], profile = null } = req.body;
    await Expense.destroy({ where: {}, truncate: true });
    await Budget.destroy({ where: {}, truncate: true });
    await Income.destroy({ where: {}, truncate: true });
    for (const e of expenses) await Expense.create({ category: e.category, amount: e.amount, date: e.date, note: e.note || '' });
    for (const b of budgets) await Budget.create({ category: b.category, month: b.month, limitAmount: b.limitAmount });
    for (const inc of incomes) await Income.create({ source: inc.source, amount: inc.amount, date: inc.date, note: inc.note || '' });
    if (profile) {
      let p = await Profile.findOne();
      if (!p) p = await Profile.create({});
      await p.update({ monthIncome: profile.monthIncome || 0, savingsGoal: profile.savingsGoal || 0, style: profile.style || '标准型', peerAvg: profile.peerAvg || 1800 });
    }
    res.json({ ok: true, msg: '已恢复', counts: { expenses: expenses.length, budgets: budgets.length, incomes: incomes.length } });
  } catch (e) { next(e); }
});

export default router;