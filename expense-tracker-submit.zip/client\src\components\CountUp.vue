<template>
  <span class="count-up">{{ display }}</span>
</template>

<script setup>
import { ref, watch, onMounted, onUnmounted } from 'vue';

const props = defineProps({
  value: { type: Number, default: 0 },
  duration: { type: Number, default: 900 },
  prefix: { type: String, default: '' },
  suffix: { type: String, default: '' },
  decimals: { type: Number, default: 2 }
});

const display = ref((props.prefix || '') + (0).toFixed(props.decimals) + (props.suffix || ''));
let raf = null;
let current = 0;

function animate(to) {
  cancelAnimationFrame(raf);
  const from = current;
  const start = performance.now();
  const step = (now) => {
    const t = Math.min(1, (now - start) / props.duration);
    const eased = 1 - Math.pow(1 - t, 3);
    current = from + (to - from) * eased;
    display.value = (props.prefix || '') + current.toFixed(props.decimals) + (props.suffix || '');
    if (t < 1) raf = requestAnimationFrame(step);
  };
  raf = requestAnimationFrame(step);
}

watch(() => props.value, (v) => animate(Number(v) || 0));
onMounted(() => animate(Number(props.value) || 0));
onUnmounted(() => cancelAnimationFrame(raf));
</script>