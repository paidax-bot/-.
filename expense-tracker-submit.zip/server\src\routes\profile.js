import { Router } from 'express';
import { Profile } from '../db.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    let p = await Profile.findOne();
    if (!p) p = await Profile.create({});
    res.json(p);
  } catch (e) { next(e); }
});

router.put('/', async (req, res, next) => {
  try {
    let p = await Profile.findOne();
    if (!p) p = await Profile.create(req.body);
    else await p.update(req.body);
    res.json(p);
  } catch (e) { next(e); }
});

export default router;