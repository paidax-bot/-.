@echo off
chcp 65001 >nul
title 打包提交源码
echo ============================================
echo    打包提交源码（排除 node_modules 等）
echo ============================================
echo.

set SRC=D:\码道code\CodeArts_programs4\expense-tracker
set DST=D:\码道code\CodeArts_programs4\expense-tracker-submit
set ZIP=D:\码道code\CodeArts_programs4\expense-tracker-submit.zip

if exist "%DST%" rmdir /s /q "%DST%"
if exist "%ZIP%" del "%ZIP%"

echo [1/3] 复制源码文件（排除 node_modules / data.db / cloudflared.exe）...
robocopy "%SRC%" "%DST%" /E /XD node_modules /XF data.db cloudflared.exe "演示启动.bat" >nul 2>&1

echo [2/3] 压缩为 zip...
powershell -Command "Compress-Archive -Path '%DST%\*' -DestinationPath '%ZIP%' -Force"

echo [3/3] 清理临时目录...
rmdir /s /q "%DST%"

echo.
echo ============================================
if exist "%ZIP%" (
    echo  打包完成！
    echo  文件位置: %ZIP%
    for %%A in ("%ZIP%") do echo  文件大小: %%~zA 字节
    echo.
    echo  把这个 zip 文件提交给评委即可。
    echo  评委解压后按 README.md 操作就能运行。
) else (
    echo  打包失败，请检查错误信息。
)
echo ============================================
echo.
pause