﻿$src = 'D:\码道code\CodeArts_programs4\expense-tracker'
$dst = 'D:\码道code\CodeArts_programs4\expense-tracker-submit'
$zip = 'D:\码道code\CodeArts_programs4\expense-tracker-submit.zip'

if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
if (Test-Path $zip) { Remove-Item $zip -Force }

Write-Host '[1/3] 复制源码（排除 node_modules / data.db / cloudflared.exe）...'
robocopy $src $dst /E /XD node_modules /XF data.db cloudflared.exe | Out-Null

Write-Host '[2/3] 压缩为 zip...'
Compress-Archive -Path "$dst\*" -DestinationPath $zip -Force

Write-Host '[3/3] 清理临时目录...'
Remove-Item $dst -Recurse -Force

if (Test-Path $zip) {
    $size = (Get-Item $zip).Length
    $sizeKB = [math]::Round($size / 1KB, 1)
    Write-Host ''
    Write-Host '============================================' -ForegroundColor Green
    Write-Host '  打包完成！' -ForegroundColor Green
    Write-Host "  文件: $zip" -ForegroundColor Green
    Write-Host "  大小: $sizeKB KB" -ForegroundColor Green
    Write-Host '============================================' -ForegroundColor Green
} else {
    Write-Host '打包失败！' -ForegroundColor Red
}