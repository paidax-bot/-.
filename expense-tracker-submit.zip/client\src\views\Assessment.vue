<template>
  <div class="assess-page">
    <div class="page-head">
      <div>
        <div class="page-eyebrow font-label">// CONSUMPTION ASSESSMENT</div>
        <h1 class="page-title font-display">花销测评</h1>
      </div>
      <div class="head-right">
        <el-date-picker v-model="month" type="month" format="YYYY-MM" value-format="YYYY-MM" :clearable="false" @change="run" />
        <el-button type="primary" @click="exportReport">导出报告</el-button>
      </div>
    </div>

    <div v-if="!result.hasData" class="empty-state cyber-panel">
      <div class="empty-icon">⊘</div>
      <div class="empty-text font-label">// {{ month }} 无消费记录，无法测评</div>
      <div class="empty-hint">前往「记账」录入支出后再来测评</div>
    </div>

    <template v-else>
      <!-- 综合分 + 雷达图 -->
      <div class="top-grid">
        <div class="cyber-panel badge-panel">
          <div class="panel-head"><span class="label-tag">RANK</span><span class="panel-title font-display">综合评级</span></div>
          <div class="badge-wrap">
            <div class="badge" :style="{ '--bc': result.color }">
              <div class="badge-ring"></div>
              <div class="badge-grade font-display" :style="{ color: result.color, textShadow: '0 0 18px ' + result.color }">{{ result.grade }}</div>
            </div>
            <div class="badge-info">
              <div class="bi-score font-display" :style="{ color: result.color }">{{ result.totalScore }}</div>
              <div class="bi-level font-label" :style="{ color: result.color }">{{ result.level }}</div>
              <div class="bi-month font-mono">{{ result.month }} · 支出 ¥{{ fmt(result.total) }}</div>
            </div>
          </div>
          <div class="score-bar-wrap">
            <div class="score-bar"><div class="score-fill" :style="{ width: result.totalScore + '%', background: 'linear-gradient(90deg,' + result.color + ',#00d4ff)' }"></div></div>
            <div class="score-marks font-mono"><span>0</span><span>60</span><span>100</span></div>
          </div>
        </div>

        <div class="cyber-panel radar-panel">
          <div class="panel-head"><span class="label-tag">RADAR</span><span class="panel-title font-display">五维能力图</span></div>
          <div ref="radarEl" class="radar-canvas"></div>
        </div>
      </div>

      <!-- 维度评分 -->
      <div class="cyber-panel dim-panel">
        <div class="panel-head"><span class="label-tag">DETAIL</span><span class="panel-title font-display">维度明细</span></div>
        <div class="dim-grid">
          <div v-for="d in result.dimensions" :key="d.key" class="dim-card">
            <div class="dim-top">
              <span class="dim-name font-label">{{ d.name }}</span>
              <span class="dim-score font-display" :style="{ color: scoreColor(d.score) }">{{ d.score }}</span>
            </div>
            <div class="dim-bar"><div class="dim-fill" :style="{ width: d.score + '%', background: scoreColor(d.score) }"></div></div>
            <div class="dim-comment font-mono">{{ d.comment }}</div>
          </div>
        </div>
      </div>

      <!-- 改进建议 -->
      <div class="cyber-panel sugg-panel">
        <div class="panel-head"><span class="label-tag">ADVICE</span><span class="panel-title font-display">改进建议</span></div>
        <div class="sugg-list">
          <div v-for="(s, i) in result.suggestions" :key="i" class="sugg-row">
            <span class="sugg-idx font-label">0{{ i + 1 }}</span>
            <span class="sugg-text font-mono">{{ s }}</span>
          </div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, nextTick } from 'vue';
import { ElMessage } from 'element-plus';
import { assessmentApi } from '../api/index.js';
import { makeChart, tooltipStyle } from '../utils/chart.js';

const fmt = (n) => (Number(n) || 0).toFixed(2);
const scoreColor = (s) => s >= 80 ? '#00ff88' : s >= 60 ? '#ffaa00' : '#ff3366';

const month = ref(new Date().toISOString().slice(0, 7));
const result = ref({ hasData: false, dimensions: [], suggestions: [], grade: '-', totalScore: 0, color: '#00ff88' });

const radarEl = ref(null);
let radarChart = null;

async function run() {
  result.value = await assessmentApi.run({ month: month.value });
  if (result.value.hasData) {
    await nextTick();
    renderRadar();
  }
}

function renderRadar() {
  if (!radarEl.value) return;
  if (!radarChart) radarChart = makeChart(radarEl.value);
  const dims = result.value.dimensions;
  radarChart.chart.setOption({
    tooltip: { ...tooltipStyle },
    radar: {
      indicator: dims.map(d => ({ name: d.name, max: 100 })),
      shape: 'polygon',
      center: ['50%', '54%'],
      radius: '68%',
      axisName: { color: '#c0c0d0', fontFamily: 'Share Tech Mono', fontSize: 12 },
      splitLine: { lineStyle: { color: '#2a2a3a' } },
      splitArea: { areaStyle: { color: ['transparent', 'rgba(0,255,136,.04)'] } },
      axisLine: { lineStyle: { color: '#2a2a3a' } }
    },
    series: [{
      type: 'radar',
      data: [{
        value: dims.map(d => d.score),
        name: '消费测评',
        areaStyle: { color: 'rgba(0,255,136,.22)' },
        lineStyle: { color: '#00ff88', width: 2, shadowBlur: 10, shadowColor: 'rgba(0,255,136,.6)' },
        itemStyle: { color: '#00ff88', borderColor: '#0a0a0f', borderWidth: 2 }
      }]
    }]
  }, true);
}

function exportReport() {
  const r = result.value;
  if (!r.hasData) return;
  const lines = [
    '═════════════════════════════════',
    '   NEON LEDGER · 消费测评报告',
    '═════════════════════════════════',
    '',
    `测评月份：${r.month}`,
    `本月支出：¥${fmt(r.total)}`,
    `综合得分：${r.totalScore} / 100`,
    `消费等级：${r.grade} 级 · ${r.level}`,
    '',
    '── 五维评分 ──',
    ...r.dimensions.map(d => `  ${d.name}：${d.score} 分 — ${d.comment}`),
    '',
    '── 改进建议 ──',
    ...r.suggestions.map((s, i) => `  ${i + 1}. ${s}`),
    '',
    `生成时间：${new Date().toLocaleString('zh-CN')}`,
    '═════════════════════════════════'
  ];
  const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `assessment-${r.month}.txt`;
  a.click();
  URL.revokeObjectURL(url);
  ElMessage.success('报告已导出');
}

onMounted(run);
onUnmounted(() => { radarChart?.dispose(); });
</script>

<style scoped>
.assess-page { display: flex; flex-direction: column; gap: 20px; }
.page-head { display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 12px; }
.page-eyebrow { color: var(--accent-3); font-size: 12px; }
.page-title { font-size: 26px; font-weight: 900; color: var(--fg); margin: 4px 0 0; }
.head-right { display: flex; gap: 10px; align-items: center; }

.empty-state { padding: 60px 20px; text-align: center; }
.empty-icon { font-size: 48px; color: var(--muted-fg); }
.empty-text { color: var(--accent-3); font-size: 14px; margin-top: 12px; }
.empty-hint { color: var(--muted-fg); font-size: 12px; margin-top: 6px; }

.top-grid { display: grid; grid-template-columns: 1fr 1.3fr; gap: 16px; }
.badge-panel { padding: 18px; }
.panel-head { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
.panel-title { color: var(--fg); font-size: 15px; }

.badge-wrap { display: flex; align-items: center; gap: 28px; justify-content: center; padding: 16px 0; }
.badge { width: 120px; height: 120px; position: relative; display: flex; align-items: center; justify-content: center; }
.badge-ring { position: absolute; inset: 0; border: 3px solid var(--bc, var(--accent)); border-radius: 50%; box-shadow: 0 0 24px var(--bc, var(--accent)), inset 0 0 18px rgba(0,255,136,.2); animation: pulse-glow 2.4s infinite; }
.badge-ring::before { content: ""; position: absolute; inset: 8px; border: 1px solid var(--bc, var(--accent)); border-radius: 50%; opacity: .4; }
.badge-grade { font-size: 64px; font-weight: 900; z-index: 1; animation: flicker 5s infinite; }
.badge-info { text-align: left; }
.bi-score { font-size: 48px; font-weight: 900; line-height: 1; }
.bi-level { font-size: 16px; margin-top: 4px; }
.bi-month { color: var(--muted-fg); font-size: 12px; margin-top: 10px; }

.score-bar-wrap { margin-top: 8px; }
.score-bar { height: 8px; background: var(--muted); overflow: hidden; }
.score-fill { height: 100%; transition: width .8s; box-shadow: 0 0 10px rgba(0,255,136,.5); }
.score-marks { display: flex; justify-content: space-between; color: var(--muted-fg); font-size: 10px; margin-top: 4px; }

.radar-panel { padding: 18px; }
.radar-canvas { width: 100%; height: 320px; }

.dim-panel { padding: 18px; }
.dim-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 14px; }
.dim-card { background: var(--bg-2); border: 1px solid var(--border); border-top: 2px solid var(--accent); padding: 14px; }
.dim-top { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 8px; }
.dim-name { color: var(--accent-3); font-size: 12px; }
.dim-score { font-size: 24px; font-weight: 700; }
.dim-bar { height: 5px; background: var(--muted); overflow: hidden; margin-bottom: 8px; }
.dim-fill { height: 100%; transition: width .6s; box-shadow: 0 0 6px currentColor; }
.dim-comment { color: var(--muted-fg); font-size: 11px; line-height: 1.5; }

.sugg-panel { padding: 18px; }
.sugg-list { display: flex; flex-direction: column; gap: 10px; }
.sugg-row { display: flex; gap: 14px; align-items: flex-start; padding: 10px 14px; background: var(--bg-2); border-left: 2px solid var(--accent); }
.sugg-idx { color: var(--accent); font-size: 13px; }
.sugg-text { color: var(--fg); font-size: 13px; line-height: 1.5; }

@media (max-width: 980px) { .top-grid { grid-template-columns: 1fr; } .dim-grid { grid-template-columns: repeat(2,1fr); } }
</style>