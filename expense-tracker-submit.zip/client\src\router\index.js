import { createRouter, createWebHistory } from 'vue-router';

const routes = [
  { path: '/', name: 'dashboard', component: () => import('../views/Dashboard.vue'), meta: { title: '控制台' } },
  { path: '/record', name: 'record', component: () => import('../views/Record.vue'), meta: { title: '记账' } },
  { path: '/stats', name: 'stats', component: () => import('../views/Stats.vue'), meta: { title: '统计' } },
  { path: '/budget', name: 'budget', component: () => import('../views/Budget.vue'), meta: { title: '预算' } },
  { path: '/plan', name: 'plan', component: () => import('../views/Plan.vue'), meta: { title: '规划' } },
  { path: '/assessment', name: 'assessment', component: () => import('../views/Assessment.vue'), meta: { title: '测评' } },
  { path: '/goal', name: 'goal', component: () => import('../views/Goal.vue'), meta: { title: '目标' } },
  { path: '/mind', name: 'mind', component: () => import('../views/Mind.vue'), meta: { title: '心理' } },
  { path: '/wishlist', name: 'wishlist', component: () => import('../views/Wishlist.vue'), meta: { title: '心愿' } }
];

const router = createRouter({ history: createWebHistory(), routes });

export default router;