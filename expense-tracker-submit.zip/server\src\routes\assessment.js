import { Router } from 'express';
import { Op } from 'sequelize';
import { Expense, Budget, Profile, Income } from '../db.js';

const router = Router();

const CATS = ['餐饮', '交通', '学习', '娱乐', '日用品', '通讯', '其他'];
const TEMPLATES = {
  '节俭型': { 餐饮: 45, 交通: 5, 学习: 15, 娱乐: 6, 日用品: 10, 通讯: 4, 其他: 15 },
  '标准型': { 餐饮: 42, 交通: 7, 学习: 12, 娱乐: 10, 日用品: 10, 通讯: 4, 其他: 5 },
  '宽松型': { 餐饮: 40, 交通: 8, 学习: 10, 娱乐: 17, 日用品: 10, 通讯: 5, 其他: 10 }
};

router.get('/', async (req, res, next) => {
  try {
    const month = req.query.month || new Date().toISOString().slice(0, 7);
    const start = `${month}-01`, end = `${month}-31`;
    let profile = await Profile.findOne();
    if (!profile) profile = await Profile.create({});
    const income = profile.monthIncome || 0;
    const savingsGoal = profile.savingsGoal || 0;
    const peerAvg = profile.peerAvg || 1800;
    const style = TEMPLATES[profile.style] ? profile.style : '标准型';
    const template = TEMPLATES[style];

    const rows = await Expense.findAll({ where: { date: { [Op.between]: [start, end] } }, raw: true });
    const catMap = {};
    let total = 0;
    rows.forEach(r => { catMap[r.category] = (catMap[r.category] || 0) + r.amount; total += r.amount; });
    const catRatio = {};
    CATS.forEach(c => { catRatio[c] = total > 0 ? (catMap[c] || 0) / total : 0; });

    const incomeRows = await Income.findAll({ where: { date: { [Op.between]: [start, end] } }, raw: true });
    const incomeTotal = incomeRows.reduce((s, r) => s + (r.amount || 0), 0);

    // 1. 合理性
    let diff = 0;
    CATS.forEach(c => { diff += Math.abs(catRatio[c] - (template[c] / 100)); });
    diff /= 2;
    const reasonScore = Math.round(Math.max(0, (1 - diff)) * 100);

    // 2. 节俭度
    const fr = peerAvg > 0 ? total / peerAvg : 1;
    let frugScore;
    if (total === 0) frugScore = 60;
    else if (fr <= 0.8) frugScore = 100;
    else if (fr <= 1) frugScore = 90;
    else if (fr <= 1.2) frugScore = 75;
    else if (fr <= 1.5) frugScore = 55;
    else frugScore = 35;
    if (fr < 0.3 && total > 0) frugScore = 80;

    // 3. 均衡性
    const vals = CATS.map(c => catMap[c] || 0).filter(v => v > 0);
    let balScore = 60;
    if (vals.length > 1) {
      const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
      const std = Math.sqrt(vals.reduce((a, b) => a + (b - mean) ** 2, 0) / vals.length);
      const cv = mean > 0 ? std / mean : 0;
      balScore = Math.round(Math.max(0, 100 - cv * 55));
    } else if (vals.length === 0) balScore = 60;

    // 4. 计划性
    const budgets = await Budget.findAll({ where: { month }, raw: true });
    let planScore = 60;
    let overCount = 0;
    if (budgets.length > 0) {
      budgets.forEach(b => { if ((catMap[b.category] || 0) > b.limitAmount) overCount++; });
      const overRate = overCount / budgets.length;
      const budgetSum = budgets.reduce((s, b) => s + b.limitAmount, 0);
      const execRate = budgetSum > 0 ? total / budgetSum : 0;
      planScore = Math.round((1 - overRate) * 70 + Math.max(0, 1 - Math.abs(execRate - 1)) * 30);
    }

    // 5. 储蓄率
    const base = incomeTotal > 0 ? incomeTotal : (income > 0 ? income : peerAvg);
    const savingsRate = base > 0 ? (base - total) / base : 0;
    let savScore;
    if (total === 0) savScore = 60;
    else savScore = Math.round(Math.max(0, Math.min(100, savingsRate / 0.2 * 100)));

    const dimensions = [
      { key: 'reason', name: '合理性', score: reasonScore, comment: reasonScore >= 80 ? '消费结构合理' : reasonScore >= 60 ? '结构基本合理，部分类别偏离' : '结构与合理比例偏差较大' },
      { key: 'frugal', name: '节俭度', score: frugScore, comment: total === 0 ? '本月无支出' : fr <= 1 ? '支出控制良好' : '支出偏高，注意节制' },
      { key: 'balance', name: '均衡性', score: balScore, comment: balScore >= 80 ? '各类别均衡' : balScore >= 60 ? '基本均衡' : '存在严重偏科' },
      { key: 'plan', name: '计划性', score: planScore, comment: budgets.length === 0 ? '未设定预算' : overCount === 0 ? '预算执行良好' : `${overCount} 个类别超支` },
      { key: 'saving', name: '储蓄率', score: savScore, comment: savScore >= 80 ? '储蓄充足' : savScore >= 60 ? '有储蓄' : '储蓄不足' }
    ];

    const totalScore = Math.round(reasonScore * 0.3 + frugScore * 0.2 + balScore * 0.15 + planScore * 0.2 + savScore * 0.15);
    let grade = 'D', level = '预警', color = '#ff3366';
    if (totalScore >= 90) { grade = 'S'; level = '卓越'; color = '#00ff88'; }
    else if (totalScore >= 80) { grade = 'A'; level = '优秀'; color = '#00d4ff'; }
    else if (totalScore >= 70) { grade = 'B'; level = '良好'; color = '#ffaa00'; }
    else if (totalScore >= 60) { grade = 'C'; level = '待改进'; color = '#ff8800'; }

    const suggestions = [];
    if (reasonScore < 70) suggestions.push('消费结构与合理比例偏差较大，建议参考「规划」页的类别建议调整支出分布');
    if (frugScore < 70 && total > 0) suggestions.push(`本月支出 ¥${total.toFixed(2)} ${fr > 1 ? '高于' : '低于'}同龄人均值 ¥${peerAvg}，建议合理控制`);
    if (balScore < 70) suggestions.push('各类别支出不均衡，存在严重偏科，建议均衡分配避免单一类别过高');
    if (planScore < 70) suggestions.push(budgets.length === 0 ? '尚未设定预算，建议前往「预算」页设定并按计划消费' : `预算执行偏差较大，${overCount > 0 ? `有 ${overCount} 个类别超支` : '建议贴近预算消费'}`);
    if (savScore < 70) suggestions.push('储蓄率偏低，建议将储蓄比例提升至 15% 以上');
    if (suggestions.length === 0) suggestions.push('各项指标良好，保持当前消费习惯');

    res.json({
      month,
      total: Math.round(total * 100) / 100,
      grade, level, color, totalScore,
      dimensions,
      suggestions,
      catRatio,
      catMap,
      hasData: total > 0
    });
  } catch (e) { next(e); }
});

export default router;