import { Router } from 'express';
import { Op } from 'sequelize';
import { Expense, Profile } from '../db.js';

const router = Router();

const CATS = ['餐饮', '交通', '学习', '娱乐', '日用品', '通讯', '其他'];
const TEMPLATES = {
  '节俭型': { 餐饮: 45, 交通: 5, 学习: 15, 娱乐: 6, 日用品: 10, 通讯: 4, 其他: 15 },
  '标准型': { 餐饮: 42, 交通: 7, 学习: 12, 娱乐: 10, 日用品: 10, 通讯: 4, 其他: 5 },
  '宽松型': { 餐饮: 40, 交通: 8, 学习: 10, 娱乐: 17, 日用品: 10, 通讯: 5, 其他: 10 }
};

router.get('/', async (req, res, next) => {
  try {
    let profile = await Profile.findOne();
    if (!profile) profile = await Profile.create({});
    const income = profile.monthIncome || 0;
    const savingsGoal = profile.savingsGoal || 0;
    const style = TEMPLATES[profile.style] ? profile.style : '标准型';
    const template = TEMPLATES[style];
    const spendable = Math.max(0, income - savingsGoal);

    const now = new Date();
    const hist = {};
    let histTotal = 0;
    for (let i = 1; i <= 3; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const m = d.toISOString().slice(0, 7);
      const rows = await Expense.findAll({ where: { date: { [Op.between]: [`${m}-01`, `${m}-31`] } }, raw: true });
      rows.forEach(r => { hist[r.category] = (hist[r.category] || 0) + r.amount; histTotal += r.amount; });
    }
    const histRatio = {};
    CATS.forEach(c => { histRatio[c] = histTotal > 0 ? (hist[c] || 0) / histTotal : 0; });

    const blended = {};
    let sum = 0;
    CATS.forEach(c => { blended[c] = (template[c] / 100) * 0.7 + histRatio[c] * 0.3; sum += blended[c]; });
    CATS.forEach(c => { blended[c] = sum > 0 ? blended[c] / sum : 1 / CATS.length; });

    const items = CATS.map(c => ({
      category: c,
      ratio: Math.round(blended[c] * 1000) / 10,
      amount: Math.round(blended[c] * spendable * 100) / 100,
      histRatio: Math.round(histRatio[c] * 1000) / 10
    }));

    const histMonthlyAvg = histTotal / 3;
    const forecastSavings = income - histMonthlyAvg;
    const canReach = forecastSavings >= savingsGoal;

    res.json({
      income, savingsGoal, spendable, style,
      items,
      histMonthlyAvg: Math.round(histMonthlyAvg * 100) / 100,
      forecastSavings: Math.round(forecastSavings * 100) / 100,
      canReach,
      hasHistory: histTotal > 0,
      advice: canReach
        ? `按近3月均值预计可存 ¥${Math.round(forecastSavings * 100) / 100}，可达成储蓄目标 ¥${savingsGoal}`
        : `按近3月均值预计仅可存 ¥${Math.round(forecastSavings * 100) / 100}，未达储蓄目标 ¥${savingsGoal}，建议削减支出`
    });
  } catch (e) { next(e); }
});

export default router;