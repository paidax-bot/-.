<template>
  <div class="wish-page">
    <div class="page-head">
      <div>
        <div class="page-eyebrow font-label">// DELAYED GRATIFICATION</div>
        <h1 class="page-title font-display">想要清单</h1>
      </div>
    </div>

    <div class="wish-grid">
      <div class="cyber-panel form-panel">
        <div class="panel-head"><span class="label-tag">ADD</span><span class="panel-title font-display">加入心愿</span></div>
        <el-form label-position="top">
          <el-form-item label="想要的东西">
            <el-input v-model="form.name" placeholder="如 新款耳机" />
          </el-form-item>
          <el-form-item label="价格 / CNY">
            <el-input v-model.number="form.price" type="number" placeholder="0">
              <template #prefix><span class="neon">¥</span></template>
            </el-input>
          </el-form-item>
          <el-form-item label="冷静期">
            <el-radio-group v-model="form.coolDays">
              <el-radio-button :label="7">7 天</el-radio-button>
              <el-radio-button :label="14">14 天</el-radio-button>
              <el-radio-button :label="30">30 天</el-radio-button>
            </el-radio-group>
          </el-form-item>
          <el-button type="primary" @click="add" style="width:100%">加入清单</el-button>
        </el-form>
        <div class="hint font-label">// 冷静期到了再决定，训练延迟满足</div>
      </div>

      <div class="cyber-panel stat-panel">
        <div class="panel-head"><span class="label-tag">RATE</span><span class="panel-title font-display">冷静通过率</span></div>
        <div class="rate-wrap">
          <div class="rate-pct font-display neon">{{ passRate }}%</div>
          <div class="rate-desc font-mono">已买 / (已买 + 放弃)</div>
          <div class="rate-bar"><div class="rate-fill" :style="{ width: passRate + '%' }"></div></div>
          <div class="rate-nums font-mono">已买 {{ boughtCount }} · 放弃 {{ abandonedCount }} · 冷静中 {{ coolingCount }}</div>
        </div>
        <div class="rate-hint font-label">{{ passRate >= 50 ? '● 延迟满足能力良好' : '● 多数冲动被冷静期拦下，继续训练' }}</div>
      </div>
    </div>

    <div class="cyber-panel list-panel">
      <div class="panel-head"><span class="label-tag">LIST</span><span class="panel-title font-display">心愿清单</span></div>
      <div class="wish-list">
        <div v-for="w in list" :key="w.id" class="wish-card" :class="w.status">
          <div class="w-top">
            <span class="w-name font-display">{{ w.name }}</span>
            <span class="w-price font-mono neon">¥{{ fmt(w.price) }}</span>
          </div>
          <div class="w-status font-label" :class="statusClass(w)">
            <span v-if="w.cooling">⏳ 冷静中 · 还剩 {{ w.daysLeft }} 天 ({{ w.coolEnd }} 解禁)</span>
            <span v-else-if="w.ready">✓ 冷静期已过 · 还要买吗？</span>
            <span v-else-if="w.status==='bought'">✓ 已入手</span>
            <span v-else-if="w.status==='abandoned'">✗ 已放弃</span>
          </div>
          <div class="w-actions" v-if="w.status==='cooling' || w.status==='abandoned' || w.status==='bought'">
            <el-button v-if="w.ready" size="small" type="primary" @click="mark(w,'bought')">决定买</el-button>
            <el-button v-if="w.ready" size="small" @click="mark(w,'abandoned')">放弃</el-button>
            <el-button v-if="w.status==='cooling' && !w.ready" size="small" @click="mark(w,'abandoned')">提前放弃</el-button>
            <el-button size="small" type="danger" @click="remove(w)">删除</el-button>
          </div>
        </div>
        <div v-if="!list.length" class="empty font-label">// 清单为空，加入一个想要的东西开始训练</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { wishlistApi } from '../api/index.js';

const fmt = (n) => (Number(n) || 0).toFixed(2);
const today = () => new Date().toISOString().slice(0, 10);
const form = reactive({ name: '', price: 0, coolDays: 7 });
const list = ref([]);

const boughtCount = computed(() => list.value.filter(w => w.status === 'bought').length);
const abandonedCount = computed(() => list.value.filter(w => w.status === 'abandoned').length);
const coolingCount = computed(() => list.value.filter(w => w.status === 'cooling').length);
const passRate = computed(() => {
  const total = boughtCount.value + abandonedCount.value;
  return total > 0 ? Math.round(boughtCount.value / total * 100) : 0;
});

const statusClass = (w) => w.cooling ? 'cooling' : w.ready ? 'ready' : w.status;

async function load() { list.value = await wishlistApi.list(); }

async function add() {
  if (!form.name) return ElMessage.warning('请输入名称');
  await wishlistApi.create({ name: form.name, price: Number(form.price) || 0, coolDays: form.coolDays, addedDate: today(), status: 'cooling' });
  ElMessage.success('已加入清单，开始冷静');
  form.name = ''; form.price = 0;
  await load();
}

async function mark(w, status) {
  await wishlistApi.update(w.id, { status });
  ElMessage.success(status === 'bought' ? '已标记入手' : '已放弃');
  await load();
}

async function remove(w) {
  await ElMessageBox.confirm(`删除「${w.name}」?`, '确认', { type: 'warning' });
  await wishlistApi.remove(w.id);
  await load();
}

onMounted(load);
</script>

<style scoped>
.wish-page { display: flex; flex-direction: column; gap: 20px; }
.page-eyebrow { color: var(--accent-3); font-size: 12px; }
.page-title { font-size: 26px; font-weight: 900; color: var(--fg); margin: 4px 0 0; }

.wish-grid { display: grid; grid-template-columns: 340px 1fr; gap: 16px; align-items: start; }
.form-panel { padding: 18px; position: sticky; top: 0; }
.panel-head { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
.panel-title { color: var(--fg); font-size: 15px; }
.hint { color: var(--muted-fg); font-size: 11px; margin-top: 12px; text-align: center; }

.stat-panel { padding: 18px; }
.rate-wrap { text-align: center; padding: 10px 0; }
.rate-pct { font-size: 42px; font-weight: 900; }
.rate-desc { color: var(--muted-fg); font-size: 12px; margin: 6px 0 14px; }
.rate-bar { height: 10px; background: var(--muted); overflow: hidden; max-width: 400px; margin: 0 auto; }
.rate-fill { height: 100%; background: linear-gradient(90deg, #00ff88, #00d4ff); box-shadow: 0 0 10px rgba(0,255,136,.5); transition: width .6s; }
.rate-nums { color: var(--muted-fg); font-size: 12px; margin-top: 12px; }
.rate-hint { text-align: center; color: var(--accent); font-size: 12px; margin-top: 8px; }

.list-panel { padding: 18px; }
.wish-list { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }
.wish-card { background: var(--bg-2); border: 1px solid var(--border); border-left: 3px solid var(--accent-3); padding: 14px; }
.wish-card.bought { border-left-color: var(--accent); opacity: .8; }
.wish-card.abandoned { border-left-color: var(--destructive); opacity: .6; }
.w-top { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 8px; }
.w-name { font-size: 16px; }
.w-price { font-weight: 700; }
.w-status { font-size: 12px; margin-bottom: 10px; min-height: 18px; }
.w-status.cooling { color: var(--accent-3); }
.w-status.ready { color: var(--accent); }
.w-status.bought { color: var(--accent); }
.w-status.abandoned { color: var(--destructive); }
.w-actions { display: flex; gap: 6px; flex-wrap: wrap; }
.empty { color: var(--muted-fg); font-size: 12px; padding: 24px; text-align: center; grid-column: 1 / -1; }

@media (max-width: 980px) { .wish-grid { grid-template-columns: 1fr; } .form-panel { position: static; } .wish-list { grid-template-columns: 1fr; } }
</style>