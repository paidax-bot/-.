<template>
  <div class="dashboard">
    <!-- 欢迎条 -->
    <div class="hero fade-in">
      <div>
        <div class="hero-eyebrow font-label">// SESSION INITIATED</div>
        <h1 class="hero-title font-display">控制台 <span class="cursor-blink"></span></h1>
        <p class="hero-sub">实时监控你的信用点流向 · 数据加密传输中</p>
      </div>
      <div class="hero-month">
        <el-button type="primary" @click="seedData" size="small">载入示例数据</el-button>
        <el-button type="danger" @click="clearData" size="small">清空数据</el-button>
        <el-button @click="exportBackup" size="small">导出备份</el-button>
        <el-button @click="importRestore" size="small">导入恢复</el-button>
        <input ref="fileInput" type="file" accept=".json" style="display:none" @change="onFileChange" />
        <el-date-picker v-model="month" type="month" format="YYYY-MM" value-format="YYYY-MM" :clearable="false" @change="loadAll" />
      </div>
    </div>

    <!-- 统计卡片 -->
    <el-skeleton v-if="loading" :rows="4" animated style="margin-top:8px" />
    <div v-else class="tiles">
      <div class="stat-tile tile scan-hover tile-click" @click="$router.push('/record')">
        <div class="tile-label font-label">本月总支出</div>
        <div class="tile-value neon"><CountUp :value="summary.total" prefix="¥" /></div>
        <div class="tile-foot font-mono">CNY · {{ month }}</div>
      </div>
      <div class="stat-tile tile scan-hover">
        <div class="tile-label font-label">记录笔数</div>
        <div class="tile-value neon-cyan"><CountUp :value="summary.count" :decimals="0" /></div>
        <div class="tile-foot font-mono">TRANSACTIONS</div>
      </div>
      <div class="stat-tile tile scan-hover">
        <div class="tile-label font-label">日均支出</div>
        <div class="tile-value neon-pink"><CountUp :value="avgDaily" prefix="¥" /></div>
        <div class="tile-foot font-mono">PER DAY</div>
      </div>
      <div class="stat-tile tile scan-hover tile-click" @click="$router.push('/budget')">
        <div class="tile-label font-label">预算使用率</div>
        <div class="tile-value" :class="overBudget ? 'neon-pink' : 'neon'"><CountUp :value="budgetRate" :decimals="0" suffix="%" /></div>
        <div class="tile-foot font-mono">{{ overBudget ? 'OVER LIMIT' : 'WITHIN RANGE' }}</div>
      </div>
      <div class="stat-tile tile scan-hover">
        <div class="tile-label font-label">本月结余</div>
        <div class="tile-value" :class="balance.balance < 0 ? 'neon-pink' : 'neon-cyan'">{{ balance.balance < 0 ? '-' : '' }}<CountUp :value="Math.abs(balance.balance)" prefix="¥" /></div>
        <div class="tile-foot font-mono">收 ¥{{ fmt(balance.income) }} · 支 ¥{{ fmt(balance.expense) }}</div>
      </div>
    </div>

    <!-- 超支警告 -->
    <div v-if="overBudget" class="alert-bar fade-in">
      <span class="alert-icon">⚠</span> 预算超支警报：本月支出已超出预算 ¥{{ fmt(summary.total - totalBudget) }}，建议节制消费。
    </div>

    <!-- 图表区 -->
    <div class="charts">
      <div class="cyber-panel chart-box">
        <div class="panel-head"><span class="label-tag">TREND</span><span class="panel-title font-display">近 6 月走势</span></div>
        <div ref="trendEl" class="chart-canvas"></div>
      </div>
      <div class="cyber-panel chart-box">
        <div class="panel-head"><span class="label-tag">RATIO</span><span class="panel-title font-display">类别占比</span></div>
        <div ref="pieEl" class="chart-canvas"></div>
      </div>
    </div>

    <!-- 消费日历热力图 -->
    <div class="cyber-panel heatmap-panel">
      <div class="panel-head"><span class="label-tag">HEATMAP</span><span class="panel-title font-display">消费日历 · 近 6 月</span></div>
      <div ref="heatmapEl" class="heatmap-canvas"></div>
    </div>

    <!-- 预算进度 + 最近记录 -->
    <div class="lower">
      <div class="cyber-panel budget-panel">
        <div class="panel-head"><span class="label-tag">LIMIT</span><span class="panel-title font-display">预算执行</span></div>
        <div class="budget-list">
          <div v-for="b in budgetView" :key="b.category" class="budget-row">
            <div class="budget-top">
              <span class="budget-cat font-label">{{ b.category }}</span>
              <span class="budget-num font-mono">¥{{ fmt(b.used) }} / ¥{{ fmt(b.limit) }}</span>
            </div>
            <div class="budget-bar">
              <div class="budget-fill" :style="{ width: b.pct + '%', background: b.over ? 'linear-gradient(90deg,#ff3366,#ff00ff)' : 'linear-gradient(90deg,#00ff88,#00d4ff)' }"></div>
            </div>
          </div>
          <div v-if="!budgetView.length" class="empty font-label">// 暂无预算设定，前往 [预算] 页面配置</div>
        </div>
      </div>

      <div class="cyber-panel recent-panel">
        <div class="panel-head"><span class="label-tag">LOG</span><span class="panel-title font-display">最近记录</span></div>
        <div class="recent-list">
          <div v-for="r in recent" :key="r.id" class="recent-row">
            <span class="r-date font-mono">{{ r.date.slice(5) }}</span>
            <span class="r-cat" :style="{ color: catColor(r.category) }">{{ r.category }}</span>
            <span class="r-note font-mono">{{ r.note || '—' }}</span>
            <span class="r-amt font-mono">-¥{{ fmt(r.amount) }}</span>
          </div>
          <div v-if="!recent.length" class="empty font-label">// 本月无记录，前往 [记账] 开始录入</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted, nextTick } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import { statsApi, expenseApi, budgetApi, seedApi, backupApi, CATEGORIES } from '../api/index.js';
import CountUp from '../components/CountUp.vue';
import { makeChart, NEON_COLORS, axisStyle, tooltipStyle, neonLineSeries } from '../utils/chart.js';

const month = ref(new Date().toISOString().slice(0, 7));
const summary = reactive({ total: 0, count: 0 });
const trendData = ref([]);
const catData = ref([]);
const recent = ref([]);
const budgets = ref([]);
const balance = ref({ income: 0, expense: 0, balance: 0 });
const loading = ref(true);

const trendEl = ref(null);
const pieEl = ref(null);
const heatmapEl = ref(null);
const fileInput = ref(null);
let trendChart = null, pieChart = null, heatmapChart = null;
const calendarData = ref([]);

const fmt = (n) => (Number(n) || 0).toFixed(2);
const catColor = (c) => NEON_COLORS[CATEGORIES.indexOf(c) % NEON_COLORS.length] || '#00ff88';

const daysPassed = computed(() => {
  const [y, m] = month.value.split('-').map(Number);
  const now = new Date();
  const sameMonth = now.getFullYear() === y && now.getMonth() === m - 1;
  return sameMonth ? now.getDate() : new Date(y, m, 0).getDate();
});
const avgDaily = computed(() => summary.count ? summary.total / daysPassed.value : 0);

const totalBudget = computed(() => budgets.value.reduce((s, b) => s + Number(b.limitAmount), 0));
const budgetRate = computed(() => totalBudget.value ? Math.min(999, Math.round(summary.total / totalBudget.value * 100)) : 0);
const overBudget = computed(() => totalBudget.value > 0 && summary.total > totalBudget.value);

const catUsedMap = computed(() => {
  const map = {};
  catData.value.forEach(c => { map[c.category] = Number(c.total); });
  return map;
});
const budgetView = computed(() => budgets.value.map(b => {
  const used = catUsedMap.value[b.category] || 0;
  const pct = Math.min(100, Math.round(used / b.limitAmount * 100));
  return { category: b.category, used, limit: b.limitAmount, pct, over: used > b.limitAmount };
}));

async function loadAll() {
  const start = `${month.value}-01`, end = `${month.value}-31`;
  const [s, t, c, r, b, cal, bal] = await Promise.all([
    statsApi.summary({ period: 'month', date: month.value }),
    statsApi.trend({ months: 6 }),
    statsApi.category({ start, end }),
    expenseApi.list({ start, end }),
    budgetApi.list({ month: month.value }),
    statsApi.calendar({ months: 6 }),
    statsApi.balance({ month: month.value })
  ]);
  summary.total = s.total; summary.count = s.count;
  trendData.value = t; catData.value = c;
  recent.value = r.slice(0, 6); budgets.value = b;
  calendarData.value = cal;
  balance.value = bal;
  await nextTick();
  renderTrend(); renderPie(); renderHeatmap();
  loading.value = false;
}

function renderTrend() {
  if (!trendEl.value) return;
  if (!trendChart) trendChart = makeChart(trendEl.value);
  trendChart.chart.setOption({
    tooltip: { trigger: 'axis', ...tooltipStyle },
    grid: { left: 50, right: 20, top: 20, bottom: 30 },
    xAxis: { type: 'category', data: trendData.value.map(d => d.month), ...axisStyle },
    yAxis: { type: 'value', ...axisStyle },
    series: [neonLineSeries({ data: trendData.value.map(d => d.total) })]
  }, true);
}

function renderPie() {
  if (!pieEl.value) return;
  if (!pieChart) pieChart = makeChart(pieEl.value);
  const data = catData.value.map((c, i) => ({ name: c.category, value: Number(c.total), itemStyle: { color: NEON_COLORS[i % NEON_COLORS.length] } }));
  pieChart.chart.setOption({
    tooltip: { trigger: 'item', formatter: '{b}: ¥{c} ({d}%)', ...tooltipStyle },
    legend: { bottom: 0, textStyle: { color: '#7a7a96', fontFamily: 'Share Tech Mono', fontSize: 11 }, itemWidth: 10, itemHeight: 10 },
    series: [{
      type: 'pie', radius: ['42%', '68%'], center: ['50%', '46%'], data,
      label: { color: '#e6e6f0', fontFamily: 'JetBrains Mono', fontSize: 11, formatter: '{d}%' },
      labelLine: { lineStyle: { color: '#2a2a3a' } },
      itemStyle: { borderColor: '#0a0a0f', borderWidth: 2 }
    }]
  }, true);
}

function renderHeatmap() {
  if (!heatmapEl.value) return;
  if (!heatmapChart) heatmapChart = makeChart(heatmapEl.value);
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth() - 5, 1);
  const range = [start.toISOString().slice(0, 10), now.toISOString().slice(0, 10)];
  const vals = calendarData.value.map(d => d[1]);
  const max = vals.length ? Math.max(...vals) : 100;
  heatmapChart.chart.setOption({
    tooltip: { ...tooltipStyle, formatter: (p) => `${p.value[0]}<br/>¥${p.value[1]}` },
    visualMap: { min: 0, max, calculable: true, orient: 'horizontal', left: 'center', bottom: 0, textStyle: { color: '#7a7a96', fontFamily: 'Share Tech Mono' }, inRange: { color: ['#0d0d16', '#003322', '#00ff88'] } },
    calendar: {
      top: 30, left: 40, right: 20, bottom: 50, range,
      cellSize: ['auto', 14], splitLine: { show: false },
      itemStyle: { color: '#12121a', borderColor: '#1c1c2e', borderWidth: 1 },
      yearLabel: { show: false },
      monthLabel: { nameMap: 'ZH', color: '#7a7a96', fontFamily: 'Share Tech Mono', fontSize: 11 },
      dayLabel: { color: '#555570', fontSize: 10 }
    },
    series: [{ type: 'heatmap', coordinateSystem: 'calendar', data: calendarData.value, itemStyle: { borderColor: '#0a0a0f', borderWidth: 1 } }]
  }, true);
}

async function seedData() {
  try {
    await ElMessageBox.confirm('将清空现有数据并导入 3 个月示例消费记录，确认？', '载入示例数据', { type: 'warning' });
  } catch { return; }
  await seedApi.run();
  ElMessage.success('示例数据已导入');
  await loadAll();
}

async function clearData() {
  try {
    await ElMessageBox.confirm('将清空所有支出、收入、预算数据，确认？', '清空数据', { type: 'warning' });
  } catch { return; }
  await seedApi.clear();
  ElMessage.success('数据已清空');
  await loadAll();
}

async function exportBackup() {
  const data = await backupApi.export();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `ledger-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  ElMessage.success('备份已导出');
}

function importRestore() {
  fileInput.value?.click();
}

async function onFileChange(e) {
  const file = e.target.files[0];
  if (!file) return;
  let data;
  try {
    data = JSON.parse(await file.text());
  } catch {
    ElMessage.error('文件格式错误，请选择正确的备份文件');
    e.target.value = '';
    return;
  }
  try {
    await ElMessageBox.confirm(`将恢复 ${data.expenses?.length || 0} 笔支出、${data.incomes?.length || 0} 笔收入、${data.budgets?.length || 0} 条预算，会覆盖当前数据，确认？`, '导入恢复', { type: 'warning' });
  } catch { e.target.value = ''; return; }
  await backupApi.restore(data);
  ElMessage.success('数据已恢复');
  e.target.value = '';
  await loadAll();
}

onMounted(loadAll);
onUnmounted(() => { trendChart?.dispose(); pieChart?.dispose(); heatmapChart?.dispose(); });
</script>

<style scoped>
.dashboard { display: flex; flex-direction: column; gap: 20px; }

.hero { display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; }
.hero-eyebrow { color: var(--accent-3); font-size: 12px; }
.hero-title { font-size: 30px; font-weight: 900; color: var(--fg); margin: 4px 0; }
.hero-sub { color: var(--muted-fg); font-size: 13px; margin: 0; }
.hero-month { }

.tiles { display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; }
.tile { padding: 20px; }
.tile-label { color: var(--muted-fg); font-size: 11px; }
.tile-value { font-family: "Orbitron", monospace; font-size: 28px; font-weight: 700; margin: 8px 0 4px; }
.tile-foot { color: var(--muted-fg); font-size: 11px; }

.alert-bar {
  background: linear-gradient(90deg, rgba(255,51,102,.18), rgba(255,0,255,.12));
  border: 1px solid var(--destructive);
  padding: 12px 18px;
  color: var(--destructive);
  font-family: "Share Tech Mono", monospace;
  letter-spacing: .05em;
  box-shadow: 0 0 14px rgba(255,51,102,.25);
}
.alert-icon { margin-right: 8px; }

.charts { display: grid; grid-template-columns: 1.4fr 1fr; gap: 16px; }
.chart-box { padding: 16px; }
.panel-head { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
.panel-title { color: var(--fg); font-size: 15px; }
.chart-canvas { width: 100%; height: 280px; }

.heatmap-panel { padding: 16px; }
.heatmap-canvas { width: 100%; height: 220px; }

.lower { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.budget-panel, .recent-panel { padding: 16px; }
.budget-list, .recent-list { display: flex; flex-direction: column; gap: 12px; margin-top: 6px; }
.budget-row { }
.budget-top { display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 5px; }
.budget-cat { color: var(--accent-3); }
.budget-num { color: var(--muted-fg); }
.budget-bar { height: 6px; background: var(--muted); border-radius: 0; overflow: hidden; }
.budget-fill { height: 100%; transition: width .5s; box-shadow: 0 0 8px rgba(0,255,136,.4); }

.recent-row { display: grid; grid-template-columns: 48px 70px 1fr auto; gap: 10px; align-items: center; padding: 8px 10px; background: var(--bg-2); border-left: 2px solid var(--border); transition: border-color .15s; }
.recent-row:hover { border-left-color: var(--accent); }
.r-date { color: var(--muted-fg); font-size: 12px; }
.r-cat { font-family: "Share Tech Mono", monospace; font-size: 12px; letter-spacing: .05em; }
.r-note { color: var(--muted-fg); font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.r-amt { color: var(--accent); font-size: 13px; font-weight: 700; }

.empty { color: var(--muted-fg); font-size: 12px; padding: 16px; text-align: center; }

@media (max-width: 980px) {
  .tiles { grid-template-columns: repeat(2, 1fr); }
  .charts, .lower { grid-template-columns: 1fr; }
}
</style>