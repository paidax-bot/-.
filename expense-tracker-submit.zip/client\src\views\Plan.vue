<template>
  <div class="plan-page">
    <div class="page-head">
      <div>
        <div class="page-eyebrow font-label">// SPEND PLANNER AI</div>
        <h1 class="page-title font-display">花销规划</h1>
      </div>
    </div>

    <div class="plan-grid">
      <!-- 输入区 -->
      <div class="cyber-panel form-panel">
        <div class="panel-head"><span class="label-tag">INPUT</span><span class="panel-title font-display">消费画像</span></div>
        <el-form label-position="top">
          <el-form-item label="月可支配金额 / CNY">
            <el-input v-model.number="form.monthIncome" type="number" placeholder="如 2000">
              <template #prefix><span class="neon">¥</span></template>
            </el-input>
          </el-form-item>
          <el-form-item label="月储蓄目标 / CNY">
            <el-input v-model.number="form.savingsGoal" type="number" placeholder="如 300">
              <template #prefix><span class="neon-cyan">¥</span></template>
            </el-input>
          </el-form-item>
          <el-form-item label="同龄人月均消费 / CNY">
            <el-input v-model.number="form.peerAvg" type="number" placeholder="如 1800">
              <template #prefix><span class="neon-pink">¥</span></template>
            </el-input>
            <div class="hint font-label">// 用于测评节俭度对比基准</div>
          </el-form-item>
          <el-form-item label="消费风格">
            <el-radio-group v-model="form.style" class="style-group">
              <el-radio-button label="节俭型">节俭型</el-radio-button>
              <el-radio-button label="标准型">标准型</el-radio-button>
              <el-radio-button label="宽松型">宽松型</el-radio-button>
            </el-radio-group>
          </el-form-item>
          <div class="form-actions">
            <el-button type="primary" @click="saveAndPlan">保存并生成规划</el-button>
          </div>
        </el-form>
        <div class="ratio-info font-label">
          <div class="ri-title">当前风格比例模板</div>
          <div v-for="c in stylePreview" :key="c.k" class="ri-row"><span>{{ c.k }}</span><span>{{ c.v }}%</span></div>
        </div>
      </div>

      <!-- 结果区 -->
      <div class="result-area">
        <div class="tiles">
          <div class="stat-tile tile">
            <div class="tile-label font-label">可支配</div>
            <div class="tile-value neon-cyan">¥{{ fmt(plan.income) }}</div>
          </div>
          <div class="stat-tile tile">
            <div class="tile-label font-label">储蓄目标</div>
            <div class="tile-value neon">¥{{ fmt(plan.savingsGoal) }}</div>
          </div>
          <div class="stat-tile tile">
            <div class="tile-label font-label">可支出</div>
            <div class="tile-value neon-pink">¥{{ fmt(plan.spendable) }}</div>
          </div>
          <div class="stat-tile tile">
            <div class="tile-label font-label">预测储蓄</div>
            <div class="tile-value" :class="plan.canReach ? 'neon' : 'neon-pink'">¥{{ fmt(plan.forecastSavings) }}</div>
          </div>
        </div>

        <div v-if="plan.advice" class="advice-bar" :class="plan.canReach ? 'ok' : 'warn'">
          <span>{{ plan.canReach ? '✓' : '⚠' }}</span> {{ plan.advice }}
        </div>

        <div class="cyber-panel suggest-panel">
          <div class="panel-head">
            <span class="label-tag">PLAN</span><span class="panel-title font-display">类别建议额度</span>
            <el-button size="small" type="primary" @click="applyBudget" style="margin-left:auto">一键应用为预算</el-button>
          </div>
          <div class="suggest-list">
            <div v-for="it in plan.items" :key="it.category" class="suggest-row">
              <span class="s-cat font-label" :style="{ color: catColor(it.category) }">{{ it.category }}</span>
              <div class="s-bar-wrap">
                <div class="s-bar"><div class="s-fill" :style="{ width: it.ratio + '%', background: catColor(it.category) }"></div></div>
              </div>
              <span class="s-ratio font-mono">{{ it.ratio }}%</span>
              <span class="s-amt font-mono neon">¥{{ fmt(it.amount) }}</span>
            </div>
          </div>
        </div>

        <div class="cyber-panel chart-panel">
          <div class="panel-head"><span class="label-tag">COMPARE</span><span class="panel-title font-display">规划占比 vs 历史占比</span></div>
          <div ref="chartEl" class="chart-canvas"></div>
          <div v-if="!plan.hasHistory" class="chart-empty font-label">// 暂无历史消费数据，仅展示规划模板</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted, nextTick } from 'vue';
import { ElMessage } from 'element-plus';
import { profileApi, planApi, budgetApi, CATEGORIES } from '../api/index.js';
import { makeChart, NEON_COLORS, axisStyle, tooltipStyle } from '../utils/chart.js';

const fmt = (n) => (Number(n) || 0).toFixed(2);
const catColor = (c) => NEON_COLORS[CATEGORIES.indexOf(c) % NEON_COLORS.length] || '#00ff88';

const STYLE_TEMPLATES = {
  '节俭型': { 餐饮: 45, 交通: 5, 学习: 15, 娱乐: 6, 日用品: 10, 通讯: 4, 其他: 15 },
  '标准型': { 餐饮: 42, 交通: 7, 学习: 12, 娱乐: 10, 日用品: 10, 通讯: 4, 其他: 5 },
  '宽松型': { 餐饮: 40, 交通: 8, 学习: 10, 娱乐: 17, 日用品: 10, 通讯: 5, 其他: 10 }
};

const form = reactive({ monthIncome: 2000, savingsGoal: 300, peerAvg: 1800, style: '标准型' });
const plan = ref({ income: 0, savingsGoal: 0, spendable: 0, items: [], forecastSavings: 0, canReach: true, advice: '', hasHistory: false });

const stylePreview = computed(() => Object.entries(STYLE_TEMPLATES[form.style] || {}).map(([k, v]) => ({ k, v })));

const chartEl = ref(null);
let chart = null;

async function loadProfile() {
  const p = await profileApi.get();
  form.monthIncome = p.monthIncome || 2000;
  form.savingsGoal = p.savingsGoal || 300;
  form.peerAvg = p.peerAvg || 1800;
  form.style = p.style || '标准型';
}

async function saveAndPlan() {
  if (!form.monthIncome || Number(form.monthIncome) <= 0) return ElMessage.warning('请输入月可支配金额');
  await profileApi.update({
    monthIncome: Number(form.monthIncome),
    savingsGoal: Number(form.savingsGoal || 0),
    peerAvg: Number(form.peerAvg || 1800),
    style: form.style
  });
  await generate();
  ElMessage.success('规划已生成');
}

async function generate() {
  plan.value = await planApi.generate();
  await nextTick();
  renderChart();
}

async function applyBudget() {
  const month = new Date().toISOString().slice(0, 7);
  for (const it of plan.value.items) {
    if (it.amount > 0) await budgetApi.set({ category: it.category, month, limitAmount: it.amount });
  }
  ElMessage.success(`已将规划写入 ${month} 预算`);
}

function renderChart() {
  if (!chartEl.value) return;
  if (!chart) chart = makeChart(chartEl.value);
  const cats = plan.value.items.map(i => i.category);
  const planVals = plan.value.items.map(i => i.ratio);
  const histVals = plan.value.items.map(i => i.histRatio || 0);
  chart.chart.setOption({
    tooltip: { trigger: 'axis', ...tooltipStyle },
    legend: { data: ['规划占比', '历史占比'], textStyle: { color: '#7a7a96', fontFamily: 'Share Tech Mono' }, top: 0 },
    grid: { left: 50, right: 20, top: 36, bottom: 30 },
    xAxis: { type: 'category', data: cats, ...axisStyle },
    yAxis: { type: 'value', max: 60, ...axisStyle, axisLabel: { ...axisStyle.axisLabel, formatter: '{value}%' } },
    series: [
      { name: '规划占比', type: 'bar', data: planVals.map((v, i) => ({ value: v, itemStyle: { color: NEON_COLORS[i % NEON_COLORS.length] } })), barGap: 0, barWidth: 14 },
      { name: '历史占比', type: 'bar', data: histVals.map(() => ({ value: 0, itemStyle: { color: '#ff00ff' } })).map((d, i) => ({ value: histVals[i], itemStyle: { color: 'rgba(255,0,255,.6)' } })), barWidth: 14 }
    ]
  }, true);
}

onMounted(async () => { await loadProfile(); await generate(); });
onUnmounted(() => { chart?.dispose(); });
</script>

<style scoped>
.plan-page { display: flex; flex-direction: column; gap: 20px; }
.page-eyebrow { color: var(--accent-3); font-size: 12px; }
.page-title { font-size: 26px; font-weight: 900; color: var(--fg); margin: 4px 0 0; }

.plan-grid { display: grid; grid-template-columns: 340px 1fr; gap: 16px; align-items: start; }
.form-panel { padding: 18px; position: sticky; top: 0; }
.panel-head { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
.panel-title { color: var(--fg); font-size: 15px; }
.hint { color: var(--muted-fg); font-size: 11px; margin-top: 4px; }
.form-actions { margin-top: 6px; }
.style-group :deep(.el-radio-button__inner) { background: var(--muted); border-color: var(--border); color: var(--fg); font-family: "Share Tech Mono", monospace; }
.style-group :deep(.el-radio-button__original-radio:checked + .el-radio-button__inner) { background: var(--accent); border-color: var(--accent); color: #06120c; box-shadow: var(--glow); }

.ratio-info { margin-top: 18px; padding-top: 14px; border-top: 1px solid var(--border); }
.ri-title { color: var(--accent-3); margin-bottom: 8px; }
.ri-row { display: flex; justify-content: space-between; color: var(--muted-fg); font-size: 11px; margin: 3px 0; }

.result-area { display: flex; flex-direction: column; gap: 16px; }
.tiles { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.tile { padding: 16px; }
.tile-label { color: var(--muted-fg); font-size: 11px; }
.tile-value { font-family: "Orbitron", monospace; font-size: 22px; font-weight: 700; margin-top: 6px; }

.advice-bar { padding: 12px 18px; font-family: "Share Tech Mono", monospace; font-size: 13px; border: 1px solid; }
.advice-bar.ok { background: rgba(0,255,136,.1); border-color: var(--accent); color: var(--accent); }
.advice-bar.warn { background: rgba(255,51,102,.1); border-color: var(--destructive); color: var(--destructive); }

.suggest-panel { padding: 18px; }
.suggest-list { display: flex; flex-direction: column; gap: 12px; }
.suggest-row { display: grid; grid-template-columns: 70px 1fr 56px 90px; gap: 10px; align-items: center; }
.s-cat { font-size: 13px; }
.s-bar-wrap { }
.s-bar { height: 8px; background: var(--muted); overflow: hidden; }
.s-fill { height: 100%; box-shadow: 0 0 6px currentColor; transition: width .5s; }
.s-ratio { color: var(--muted-fg); font-size: 12px; text-align: right; }
.s-amt { font-size: 13px; font-weight: 700; text-align: right; }

.chart-panel { padding: 18px; position: relative; }
.chart-canvas { width: 100%; height: 280px; }
.chart-empty { position: absolute; bottom: 20px; left: 0; right: 0; text-align: center; color: var(--muted-fg); font-size: 12px; }

@media (max-width: 980px) { .plan-grid { grid-template-columns: 1fr; } .form-panel { position: static; } .tiles { grid-template-columns: repeat(2,1fr); } }
</style>