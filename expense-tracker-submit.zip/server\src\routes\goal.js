import { Router } from 'express';
import { Op } from 'sequelize';
import { Goal, Expense, Income } from '../db.js';

const router = Router();

router.get('/', async (req, res, next) => {
  try {
    let goal = await Goal.findOne();
    const totalIncome = await Income.sum('amount') || 0;
    const totalExpense = await Expense.sum('amount') || 0;
    const saved = Math.round((totalIncome - totalExpense) * 100) / 100;
    let calc = null;
    if (goal) {
      const target = goal.targetAmount;
      const remaining = Math.round((target - saved) * 100) / 100;
      const today = new Date();
      const deadline = new Date(goal.deadline);
      const daysLeft = Math.max(0, Math.ceil((deadline - today) / 86400000));
      const dailyNeed = daysLeft > 0 ? Math.round(remaining / daysLeft * 100) / 100 : 0;
      const progress = target > 0 ? Math.min(100, Math.round(saved / target * 100)) : 0;
      const now = new Date();
      let histSavings = 0;
      for (let i = 1; i <= 3; i++) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const m = d.toISOString().slice(0, 7);
        const inc = await Income.sum('amount', { where: { date: { [Op.between]: [`${m}-01`, `${m}-31`] } } }) || 0;
        const exp = await Expense.sum('amount', { where: { date: { [Op.between]: [`${m}-01`, `${m}-31`] } } }) || 0;
        histSavings += (inc - exp);
      }
      const avgMonthlySavings = histSavings / 3;
      let forecastDate = null;
      if (avgMonthlySavings > 0 && remaining > 0) {
        const monthsNeed = remaining / avgMonthlySavings;
        const fd = new Date(now.getFullYear(), now.getMonth() + monthsNeed, now.getDate());
        forecastDate = fd.toISOString().slice(0, 10);
      }
      calc = { saved, target, remaining, daysLeft, dailyNeed, progress, forecastDate, avgMonthlySavings: Math.round(avgMonthlySavings * 100) / 100 };
    }
    res.json({ goal, saved, calc });
  } catch (e) { next(e); }
});

router.put('/', async (req, res, next) => {
  try {
    const { name, targetAmount, deadline } = req.body;
    let g = await Goal.findOne();
    if (!g) g = await Goal.create({ name, targetAmount, deadline });
    else await g.update({ name, targetAmount, deadline });
    res.json(g);
  } catch (e) { next(e); }
});

export default router;